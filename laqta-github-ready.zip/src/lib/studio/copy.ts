import type { Lang, NavId, ProjectTab, StepId } from "./types";

export type Copy = {
  app: string;
  studio: string;
  langAr: string;
  langEn: string;
  step: (n: number) => string;
  next: string;
  back: string;
  enter: string;
  nameQ: string;
  nameHint: string;
  namePh: string;
  nicheQ: string;
  cadenceQ: string;
  cadenceHint: string;
  short: string;
  long: string;
  mix: string;
  perWeek: string;
  times: (n: number) => string;
  goal: string;
  goalN: (n: number) => string;
  previewKicker: string;
  also: string;
  subs: string;
  nav: Record<NavId, string>;
  hello: (name: string) => string;
  nextStep: string;
  openStep: string;
  hookLabel: string;
  streak: string;
  streakHint: string;
  saved: string;
  drafts: string;
  published: string;
  weekPlan: string;
  publishDay: string;
  restDay: string;
  note: string;
  noProject: string;
  pickIdea: string;
  ideasTitle: string;
  ideasHint: string;
  generate: string;
  savedOnly: string;
  save: string;
  savedDone: string;
  start: string;
  why: string;
  aboutMin: (n: number) => string;
  easy: string;
  mid: string;
  alts: string;
  altsLocal: string;
  altsGrok: string;
  useTitle: string;
  useHook: string;
  working: string;
  projectTitle: string;
  emptyProject: string;
  goIdeas: string;
  tabs: Record<ProjectTab, string>;
  score: string;
  chars: string;
  titlePh: string;
  scriptHint: string;
  thumbHint: string;
  thumbCount: (n: number) => string;
  thumbBad: string;
  thumbGood: string;
  doList: string;
  dontList: string;
  dos: string[];
  donts: string[];
  description: string;
  tags: string;
  copy: string;
  copied: string;
  copyPack: string;
  refreshDesc: string;
  publishCta: string;
  viewsPh: string;
  notePh: string;
  confirmPublish: string;
  cancel: string;
  filmReady: string;
  growthTitle: string;
  growthHint: string;
  insight: string;
  views: string;
  lesson: string;
  saveNumbers: string;
  noChart: string;
  milestone: string;
  reached: string;
  now: string;
  subsNow: string;
  channel: string;
  niche: string;
  cadence: string;
  settings: string;
  settingsHint: string;
  steps: Record<StepId, { title: string; detail: string }>;
  statusDraft: string;
  statusLive: string;
  switchProject: string;
  guideTitle: string;
  guideHint: string;
  example: string;
  beatHint: string;
};

const ar: Copy = {
  app: "لقطة",
  studio: "استوديو المبتدئ",
  langAr: "عربي",
  langEn: "EN",
  step: (n) => `الخطوة ${n} من ٣`,
  next: "التالي",
  back: "رجوع",
  enter: "ادخل الاستوديو",
  nameQ: "ما اسم القناة؟",
  nameHint: "يمكن تغييره لاحقًا. نحتاجه حتى تبقى النصيحة موجهة لك.",
  namePh: "مثلًا: ببساطة",
  nicheQ: "عن ماذا ستصنع الفيديوهات أول شهر؟",
  cadenceQ: "كيف ستنشر؟",
  cadenceHint: "الثبات يتقدم على الكثرة. اختر ما تستطيع حمايته.",
  short: "قصير",
  long: "طويل",
  mix: "الاثنان",
  perWeek: "فيديوهات في الأسبوع",
  times: (n) => (n === 1 ? "مرة" : n === 2 ? "مرتان" : "٣ مرات"),
  goal: "هدف المشتركين",
  goalN: (n) => n.toLocaleString("ar"),
  previewKicker: "أول فيديو سنشكّله معًا",
  also: "وأيضًا على الطاولة",
  subs: "المشتركون",
  nav: { today: "اليوم", ideas: "أفكار", project: "فيديو", growth: "نمو", guide: "دليل" },
  hello: (name) => name,
  nextStep: "الخطوة التالية",
  openStep: "افتح هذه الخطوة",
  hookLabel: "الخطاف",
  streak: "استمرارية",
  streakHint: "تزيد حين تعمل على فيديو، لا بمجرد فتح الصفحة.",
  saved: "محفوظة",
  drafts: "مسودات",
  published: "منشور",
  weekPlan: "أيام النشر",
  publishDay: "يوم نشر",
  restDay: "راحة",
  note: "ملاحظة اليوم",
  noProject: "لا يوجد فيديو قيد العمل.",
  pickIdea: "اختر فكرة",
  ideasTitle: "دفعة أفكار",
  ideasHint: "كل بطاقة عنوان وخطاف وسبب. احفظ ما يلامسك أو حوّله إلى فيديو.",
  generate: "ولّد دفعة",
  savedOnly: "المحفوظ فقط",
  save: "احفظ",
  savedDone: "محفوظ",
  start: "ابدأ الفيديو",
  why: "لماذا قد يعمل",
  aboutMin: (n) => `حوالي ${n} د`,
  easy: "سهل التصوير",
  mid: "يحتاج تجربة",
  alts: "بدائل أقوى",
  altsLocal: "بدائل من قواعد لقطة",
  altsGrok: "صاغها Grok",
  useTitle: "استخدم العنوان",
  useHook: "استخدم الخطاف",
  working: "نصيغ…",
  projectTitle: "الفيديو الحالي",
  emptyProject: "لم تبدأ فيديو بعد. الفكرة تبقى فكرة حتى تُفتح لها مسودة.",
  goIdeas: "إلى الأفكار",
  tabs: { title: "العنوان", script: "السكربت", thumb: "الصورة", pack: "النشر" },
  score: "درجة العنوان",
  chars: "حرف",
  titlePh: "اكتب الوعد، لا اسم الموضوع فقط",
  scriptHint: "هذا كلام يُقال أمام الكاميرا. عدّل الجملة حتى تشبه صوتك، واترك فكرة واحدة.",
  thumbHint: "النص فوق الصورة، لا العنوان كله. أربع كلمات حدًا أقصى.",
  thumbCount: (n) => `${n} / ٤ كلمات`,
  thumbBad: "زِد الوضوح أو احذف كلمة.",
  thumbGood: "الطول مناسب للصورة المصغّرة.",
  doList: "افعل",
  dontList: "لا تفعل",
  dos: ["عنصر واحد كبير", "تباين يُرى من بعيد", "كلمة تكمل العنوان ولا تنسخه"],
  donts: ["فقرة مكتوبة", "شعار القناة وحده", "وجوه صغيرة في الزاوية"],
  description: "الوصف",
  tags: "الوسوم",
  copy: "انسخ",
  copied: "تم النسخ",
  copyPack: "انسخ حزمة النشر",
  refreshDesc: "أعد بناء الوصف من العنوان",
  publishCta: "نشرت الفيديو",
  viewsPh: "المشاهدات الآن، أو صفر إن كان للتو",
  notePh: "ماذا سأكرر في الفيديو التالي؟",
  confirmPublish: "سجّل النشر",
  cancel: "إلغاء",
  filmReady: "الهيكل جاهز. صوّر بالهاتف، ضوء النافذة أمامك، والخطاف ثلاث لقطات.",
  growthTitle: "النمو",
  growthHint: "أرقام قليلة وقرار واحد. لا لوحة تحليل ضخمة قبل أن يوجد ما يُحلَّل.",
  insight: "القراءة",
  views: "مشاهدات",
  lesson: "ماذا أكرر",
  saveNumbers: "احفظ الرقم",
  noChart: "سيظهر الرسم بعد أول فيديو منشور.",
  milestone: "المحطة التالية",
  reached: "بلغت هذه المحطة",
  now: "الآن",
  subsNow: "المشتركون الآن",
  channel: "اسم القناة",
  niche: "الموضوع",
  cadence: "شكل الفيديو",
  settings: "إعدادات القناة",
  settingsHint: "الأفكار الجديدة والدليل يستخدمان هذا الاختيار. المسودات الحالية تبقى كما هي.",
  steps: {
    title: {
      title: "قوِّ العنوان",
      detail: "الدرجة منخفضة. أضف رقمًا أو وعدًا ملموسًا، واحذف أي صراخ.",
    },
    script: {
      title: "أكمل السكربت",
      detail: "هناك لقطة قصيرة جدًا. اكتب جملة تُقال، لا عنوانًا داخليًا.",
    },
    thumb: {
      title: "اختصر نص الصورة",
      detail: "من كلمة إلى أربع. إن احتجت الشرح، فالشرح مكانه العنوان لا الصورة.",
    },
    film: {
      title: "ثبّت ما قبل التصوير",
      detail: "خمسة بنود. أربعة منها تكفي لتضغط تسجيل وأنت مطمئن.",
    },
    pack: {
      title: "جهّز حزمة النشر",
      detail: "ستة بنود من ثمانية تكفي لأول رفع. لا تنتظر الكمال.",
    },
    filmgo: {
      title: "صوّر ثم ارفع",
      detail: "الورقة جاهزة. بعد النشر ارجع واكتب المشاهدات خلال يومين.",
    },
    done: {
      title: "هذا الفيديو منشور",
      detail: "الخطوة التالية في النمو: رقم المشاهدات، ثم جزء ثانٍ بنفس الوعد.",
    },
  },
  statusDraft: "مسودة",
  statusLive: "منشور",
  switchProject: "الفيديوهات",
  guideTitle: "دليل البداية",
  guideHint: "قواعد قصيرة. اقرأ قسمًا واحدًا ثم عد إلى الفيديو، لا تحفظ الدليل.",
  example: "ادخل بمثال جاهز",
  beatHint: "لقطة",
};

const en: Copy = {
  app: "Laqta",
  studio: "Beginner studio",
  langAr: "عربي",
  langEn: "EN",
  step: (n) => `Step ${n} of 3`,
  next: "Next",
  back: "Back",
  enter: "Enter the studio",
  nameQ: "What is the channel called?",
  nameHint: "You can change it later. We use it so the advice stays addressed to you.",
  namePh: "e.g. Plainly",
  nicheQ: "What will the videos be about this first month?",
  cadenceQ: "How will you publish?",
  cadenceHint: "Consistency beats volume. Pick what you can protect.",
  short: "Short",
  long: "Long",
  mix: "Both",
  perWeek: "Videos a week",
  times: (n) => (n === 1 ? "Once" : n === 2 ? "Twice" : "3 times"),
  goal: "Subscriber goal",
  goalN: (n) => n.toLocaleString("en"),
  previewKicker: "The first video we will shape",
  also: "Also on the table",
  subs: "Subscribers",
  nav: { today: "Today", ideas: "Ideas", project: "Video", growth: "Growth", guide: "Guide" },
  hello: (name) => name,
  nextStep: "Next step",
  openStep: "Open this step",
  hookLabel: "Hook",
  streak: "Streak",
  streakHint: "It grows when you work on a video, not when you only open the page.",
  saved: "Saved",
  drafts: "Drafts",
  published: "Published",
  weekPlan: "Publish days",
  publishDay: "Publish day",
  restDay: "Rest",
  note: "Today's note",
  noProject: "No video in progress.",
  pickIdea: "Pick an idea",
  ideasTitle: "A batch of ideas",
  ideasHint: "Each card is a title, a hook, and a reason. Save what fits or turn it into a video.",
  generate: "New batch",
  savedOnly: "Saved only",
  save: "Save",
  savedDone: "Saved",
  start: "Start video",
  why: "Why it can work",
  aboutMin: (n) => `About ${n} min`,
  easy: "Easy to film",
  mid: "Needs a trial",
  alts: "Stronger options",
  altsLocal: "Options from Laqta's rules",
  altsGrok: "Shaped by Grok",
  useTitle: "Use title",
  useHook: "Use hook",
  working: "Shaping…",
  projectTitle: "Current video",
  emptyProject: "You have not started a video. An idea stays an idea until it has a draft.",
  goIdeas: "Go to ideas",
  tabs: { title: "Title", script: "Script", thumb: "Thumb", pack: "Publish" },
  score: "Title score",
  chars: "chars",
  titlePh: "Write the promise, not only the topic name",
  scriptHint: "This is spoken on camera. Edit the line until it sounds like you, and keep one idea.",
  thumbHint: "Text on the image, not the whole title. Four words at most.",
  thumbCount: (n) => `${n} / 4 words`,
  thumbBad: "Make it clearer or cut a word.",
  thumbGood: "The length fits a thumbnail.",
  doList: "Do",
  dontList: "Don't",
  dos: ["One large element", "Contrast that reads from far away", "A word that adds to the title"],
  donts: ["A written paragraph", "Only the channel logo", "Tiny faces in the corner"],
  description: "Description",
  tags: "Tags",
  copy: "Copy",
  copied: "Copied",
  copyPack: "Copy the publish pack",
  refreshDesc: "Rebuild the description from the title",
  publishCta: "I published it",
  viewsPh: "Views right now, or zero if it just went up",
  notePh: "What will I repeat in the next video?",
  confirmPublish: "Log the publish",
  cancel: "Cancel",
  filmReady: "The page is ready. Film on your phone, window light in front, hook in three takes.",
  growthTitle: "Growth",
  growthHint: "A few numbers and one decision. No giant analytics board before there is something to analyze.",
  insight: "Reading",
  views: "Views",
  lesson: "What to repeat",
  saveNumbers: "Save number",
  noChart: "The chart appears after the first published video.",
  milestone: "Next milestone",
  reached: "You reached this one",
  now: "Now",
  subsNow: "Subscribers now",
  channel: "Channel name",
  niche: "Topic",
  cadence: "Video shape",
  settings: "Channel settings",
  settingsHint: "New ideas and the guide use this choice. Current drafts stay as they are.",
  steps: {
    title: {
      title: "Strengthen the title",
      detail: "The score is low. Add a number or a concrete promise, and cut anything that shouts.",
    },
    script: {
      title: "Finish the script",
      detail: "One shot is too short. Write a sentence you can say, not an internal heading.",
    },
    thumb: {
      title: "Shorten the thumbnail text",
      detail: "One to four words. If it needs an explanation, that belongs in the title.",
    },
    film: {
      title: "Lock the pre-film checks",
      detail: "Five items. Four of them are enough to hit record with a steady hand.",
    },
    pack: {
      title: "Prepare the publish pack",
      detail: "Six of eight is enough for a first upload. Do not wait for perfect.",
    },
    filmgo: {
      title: "Film, then upload",
      detail: "The page is ready. After publishing, come back and write the views within two days.",
    },
    done: {
      title: "This video is published",
      detail: "The next step lives in Growth: the view count, then a second part with the same promise.",
    },
  },
  statusDraft: "Draft",
  statusLive: "Published",
  switchProject: "Videos",
  guideTitle: "Starter guide",
  guideHint: "Short rules. Read one section, then go back to the video. Do not memorize the guide.",
  example: "Enter with a ready example",
  beatHint: "Shot",
};

export function copyOf(lang: Lang): Copy {
  return lang === "ar" ? ar : en;
}
