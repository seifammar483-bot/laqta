import { create } from "zustand";
import { persist } from "zustand/middleware";
import { buildBeats, buildDescription, dayKey, makeIdeas, projectDraftFromIdea, yesterdayKey } from "./engine";
import { nicheById } from "./catalog";
import type { Cadence, Idea, Lang, NavId, NicheId, Profile, Project, ProjectTab } from "./types";

type State = {
  profile: Profile;
  ideas: Idea[];
  projects: Project[];
  activeProjectId: string | null;
  seed: number;
  nav: NavId;
  projectTab: ProjectTab;
  setLang: (lang: Lang) => void;
  setNav: (nav: NavId) => void;
  setProjectTab: (tab: ProjectTab) => void;
  patchProfile: (patch: Partial<Profile>) => void;
  completeOnboarding: (input: {
    channel: string;
    niche: NicheId;
    format: Cadence;
    perWeek: 1 | 2 | 3;
    subsGoal: number;
    ideas: Idea[];
  }) => void;
  generateBatch: (niche: NicheId, format: Cadence) => void;
  toggleSave: (id: string) => void;
  applyIdeaCopy: (id: string, patch: Partial<Pick<Idea, "title" | "hook">>) => void;
  startProject: (ideaId: string) => void;
  updateProject: (id: string, patch: Partial<Project>) => void;
  toggleCheck: (id: string, key: string, kind: "film" | "checklist") => void;
  setBeat: (id: string, beatId: string, body: string) => void;
  rebuildDescription: (id: string) => void;
  markPublished: (id: string, views: number, note: string) => void;
  setViews: (id: string, views: number, note: string) => void;
};

const initialProfile: Profile = {
  channel: "",
  niche: "explain",
  format: "short",
  perWeek: 2,
  subsGoal: 1000,
  subsNow: 0,
  lang: "ar",
  onboarded: false,
  streak: 0,
  lastDay: null,
};

function touched(profile: Profile): Pick<Profile, "streak" | "lastDay"> {
  const today = dayKey();
  if (profile.lastDay === today) return { streak: profile.streak, lastDay: profile.lastDay };
  if (profile.lastDay === yesterdayKey()) return { streak: profile.streak + 1, lastDay: today };
  return { streak: 1, lastDay: today };
}

export const useStudio = create<State>()(
  persist(
    (set, get) => ({
      profile: initialProfile,
      ideas: [],
      projects: [],
      activeProjectId: null,
      seed: 11,
      nav: "today",
      projectTab: "title",
      setLang: (lang) => set((s) => ({ profile: { ...s.profile, lang } })),
      setNav: (nav) => set({ nav }),
      setProjectTab: (projectTab) => set({ projectTab }),
      patchProfile: (patch) => set((s) => ({ profile: { ...s.profile, ...patch } })),
      completeOnboarding: (input) => {
        const lang = get().profile.lang;
        const first = input.ideas[0];
        const project = first ? { ...projectDraftFromIdea(first), id: crypto.randomUUID() } : null;
        set((s) => ({
          profile: {
            ...s.profile,
            channel: input.channel.trim(),
            niche: input.niche,
            format: input.format,
            perWeek: input.perWeek,
            subsGoal: input.subsGoal,
            lang,
            onboarded: true,
            streak: 1,
            lastDay: dayKey(),
          },
          ideas: input.ideas,
          projects: project ? [project, ...s.projects] : s.projects,
          activeProjectId: project?.id ?? s.activeProjectId,
          seed: s.seed + 1,
          nav: "today",
          projectTab: "title",
        }));
      },
      generateBatch: (niche, format) =>
        set((s) => {
          const fresh = makeIdeas({ niche, format, lang: s.profile.lang, seed: s.seed + 1, count: 4 });
          return {
            ideas: [...fresh, ...s.ideas].slice(0, 40),
            seed: s.seed + 1,
            profile: { ...s.profile, ...touched(s.profile) },
          };
        }),
      toggleSave: (id) =>
        set((s) => ({
          ideas: s.ideas.map((idea) => (idea.id === id ? { ...idea, saved: !idea.saved } : idea)),
          profile: { ...s.profile, ...touched(s.profile) },
        })),
      applyIdeaCopy: (id, patch) =>
        set((s) => ({
          ideas: s.ideas.map((idea) => (idea.id === id ? { ...idea, ...patch } : idea)),
        })),
      startProject: (ideaId) => {
        const idea = get().ideas.find((item) => item.id === ideaId);
        if (!idea) return;
        const project = { ...projectDraftFromIdea(idea), id: crypto.randomUUID() };
        set((s) => ({
          projects: [project, ...s.projects],
          activeProjectId: project.id,
          nav: "project",
          projectTab: "title",
          profile: { ...s.profile, ...touched(s.profile) },
        }));
      },
      updateProject: (id, patch) =>
        set((s) => ({
          projects: s.projects.map((project) => (project.id === id ? { ...project, ...patch } : project)),
          profile: { ...s.profile, ...touched(s.profile) },
        })),
      toggleCheck: (id, key, kind) =>
        set((s) => ({
          projects: s.projects.map((project) => {
            if (project.id !== id) return project;
            const bag = project[kind];
            return { ...project, [kind]: { ...bag, [key]: !bag[key] } };
          }),
          profile: { ...s.profile, ...touched(s.profile) },
        })),
      setBeat: (id, beatId, body) =>
        set((s) => ({
          projects: s.projects.map((project) =>
            project.id === id
              ? { ...project, beats: project.beats.map((item) => (item.id === beatId ? { ...item, body } : item)) }
              : project,
          ),
          profile: { ...s.profile, ...touched(s.profile) },
        })),
      rebuildDescription: (id) =>
        set((s) => ({
          projects: s.projects.map((project) => {
            if (project.id !== id) return project;
            const niche = nicheById(project.niche);
            const beats = buildBeats(project, niche);
            return { ...project, description: buildDescription(project, niche, beats) };
          }),
        })),
      markPublished: (id, views, note) =>
        set((s) => ({
          projects: s.projects.map((project) =>
            project.id === id
              ? {
                  ...project,
                  status: "published",
                  publishedAt: project.publishedAt ?? new Date().toISOString(),
                  views: Math.max(0, Math.round(views)),
                  note,
                }
              : project,
          ),
          nav: "growth",
          profile: { ...s.profile, ...touched(s.profile) },
        })),
      setViews: (id, views, note) =>
        set((s) => ({
          projects: s.projects.map((project) =>
            project.id === id ? { ...project, views: Math.max(0, Math.round(views)), note } : project,
          ),
        })),
    }),
    {
      name: "laqta-studio",
      version: 1,
      partialize: (s) => ({
        profile: s.profile,
        ideas: s.ideas,
        projects: s.projects,
        activeProjectId: s.activeProjectId,
        seed: s.seed,
      }),
    },
  ),
);

export function selectActive(state: Pick<State, "projects" | "activeProjectId">) {
  return (
    state.projects.find((project) => project.id === state.activeProjectId) ??
    state.projects.find((project) => project.status === "draft") ??
    null
  );
}
