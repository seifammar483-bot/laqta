import {
  FILM_CHECKS,
  HOOKS,
  NICHES,
  PATTERNS,
  PUBLISH_CHECKS,
  THUMB_LINES,
  nicheById,
  type Niche,
} from "./catalog";
import type { Beat, Format, Idea, Lang, NicheId, Project, StepId } from "./types";

export function dayKey(d = new Date()) {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function yesterdayKey() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return dayKey(d);
}

export function wordCount(value: string) {
  return value.trim().split(/\s+/).filter(Boolean).length;
}

export function fill(template: string, vars: Record<string, string>) {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => vars[key] ?? "");
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(items: T[], rng: () => number) {
  const next = [...items];
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [next[i], next[j]] = [next[j], next[i]];
  }
  return next;
}

function emptyMap(list: { id: string }[]) {
  return Object.fromEntries(list.map((item) => [item.id, false]));
}

export function makeIdeas(opts: {
  niche: NicheId;
  format: Format | "mix";
  lang: Lang;
  seed: number;
  count?: number;
}): Idea[] {
  const count = opts.count ?? 4;
  const rng = mulberry32(opts.seed || 1);
  const niche = nicheById(opts.niche);
  const topics = shuffle(niche.topics[opts.lang], rng);
  const ideas: Idea[] = [];
  for (let i = 0; i < count; i++) {
    const topic = topics[i % topics.length] ?? niche.name[opts.lang];
    const format: Format = opts.format === "mix" ? (i % 2 === 0 ? "short" : "long") : opts.format;
    const pattern = PATTERNS[Math.floor(rng() * PATTERNS.length)] ?? PATTERNS[0];
    const hook = HOOKS[Math.floor(rng() * HOOKS.length)] ?? HOOKS[0];
    const minutes = format === "short" ? (rng() < 0.5 ? 1 : 3) : rng() < 0.5 ? 8 : 10;
    const n = format === "short" ? 3 : 5;
    const vars = { topic, minutes: String(minutes), n: String(n) };
    ideas.push({
      id: `idea-${opts.seed}-${i}-${topic}`,
      niche: opts.niche,
      format,
      lang: opts.lang,
      topic,
      title: fill(pattern.text[opts.lang], vars),
      hook: fill(hook[opts.lang], vars),
      why: pattern.why[opts.lang],
      minutes,
      difficulty: pattern.mid ? "mid" : "easy",
      saved: false,
    });
  }
  return ideas;
}

export function altTitles(idea: { topic: string; lang: Lang; format: Format; title: string; minutes?: number }) {
  const n = idea.format === "short" ? "3" : "5";
  const minutes = idea.minutes ?? (idea.format === "short" ? 3 : 8);
  const vars = { topic: idea.topic, minutes: String(minutes), n };
  return PATTERNS.map((pattern) => fill(pattern.text[idea.lang], vars)).filter((title) => title !== idea.title).slice(0, 3);
}

const POWER_AR = ["خطأ", "أخطاء", "لا تبدأ", "حقيقة", "أسهل", "بدون", "قبل", "جرّبت", "نتيجة", "مبتدئ", "كيف", "خلال"];
const POWER_EN = ["mistake", "mistakes", "don't", "truth", "easiest", "without", "before", "tried", "result", "beginner", "how", "minutes"];

export function scoreTitle(title: string, lang: Lang) {
  const text = title.trim();
  const notes: { tone: "good" | "bad" | "warn"; text: string }[] = [];
  if (!text) {
    return {
      score: 0,
      notes: [
        {
          tone: "bad" as const,
          text: lang === "ar" ? "العنوان فارغ. اكتب الوعد أولًا." : "The title is empty. Write the promise first.",
        },
      ],
    };
  }
  let score = 40;
  const len = text.length;
  const arabic = /[\u0600-\u06FF]/.test(text);
  const sweet = arabic ? len >= 28 && len <= 72 : len >= 36 && len <= 70;
  if (sweet) {
    score += 18;
    notes.push({
      tone: "good",
      text: lang === "ar" ? "الطول مناسب ليُقرأ في الرئيسية دون أن يُقطع." : "Length should read on the home feed without getting cut.",
    });
  } else if (len < 20) {
    score -= 8;
    notes.push({
      tone: "warn",
      text: lang === "ar" ? "قصير جدًا. أضف لمن هو الفيديو أو ماذا سيحصل." : "Too short. Add who it is for, or what happens.",
    });
  } else {
    score -= 4;
    notes.push({
      tone: "warn",
      text: lang === "ar" ? "الطول خارج المجال المريح. اجعله يُقال في نفس واحد." : "Outside the comfortable range. It should fit in one breath.",
    });
  }
  if (/\d/.test(text)) {
    score += 12;
    notes.push({
      tone: "good",
      text: lang === "ar" ? "فيه رقم. الأرقام أوضح من الصفات العامة." : "It has a number. Numbers are clearer than vague adjectives.",
    });
  } else {
    notes.push({
      tone: "warn",
      text: lang === "ar" ? "أضف رقمًا: ٣ أخطاء، ٧ أيام، أو مدة بالدقائق." : "Add a number: 3 mistakes, 7 days, or a minute count.",
    });
  }
  const powers = arabic ? POWER_AR : POWER_EN;
  const hit = powers.find((word) => text.toLowerCase().includes(word.toLowerCase()));
  if (hit) {
    score += 10;
    notes.push({
      tone: "good",
      text: lang === "ar" ? `فيه وعد ملموس («${hit}»).` : `It has a concrete promise (“${hit}”).`,
    });
  } else {
    notes.push({
      tone: "warn",
      text: lang === "ar" ? "لا يوجد وعد ملموس مثل خطأ، نتيجة، أو أسهل." : "No concrete promise such as mistake, result, or easiest.",
    });
  }
  if (/دقيق|ثوان|يوم|أسبوع|minute|second|day|week/i.test(text)) {
    score += 6;
    notes.push({
      tone: "good",
      text: lang === "ar" ? "الإطار الزمني يقلل تردد المشاهد." : "A time frame lowers the viewer's hesitation.",
    });
  }
  if (/لن تصدق|لن تُصدق|you won't believe|shocking|لن تتوقع/i.test(text)) {
    score -= 16;
    notes.push({
      tone: "bad",
      text: lang === "ar" ? "هذا وعد فارغ. استبدله بنتيجة محددة." : "That is an empty promise. Replace it with a specific result.",
    });
  }
  if (text === text.toUpperCase() && /[A-Z]/.test(text) && text.length > 8) {
    score -= 8;
    notes.push({
      tone: "bad",
      text: lang === "ar" ? "الأحرف الكبيرة كلها تبدو كصراخ. اخفضها." : "All caps reads as shouting. Lower it.",
    });
  }
  return { score: Math.max(8, Math.min(96, score)), notes };
}

function beat(id: string, seconds: string, label: string, body: string): Beat {
  return { id, seconds, label, body };
}

export function buildBeats(
  idea: { topic: string; format: Format; lang: Lang; hook: string; minutes?: number },
  niche: Niche,
): Beat[] {
  const lang = idea.lang;
  const topic = idea.topic;
  if (lang === "ar") {
    if (idea.format === "short") {
      return [
        beat("hook", "0–3", "الخطاف", idea.hook),
        beat("promise", "3–8", "الوعد", `إذا بقيت، ستخرج بخطوة واحدة في ${topic}: ${niche.firstStep.ar}.`),
        beat("point", "8–25", "الفكرة", `الغلطة الشائعة هي ${niche.trap.ar}. اعكسها اليوم ولا تضف محورًا ثانيًا.`),
        beat("example", "25–40", "المثال", niche.proof.ar.endsWith(".") ? niche.proof.ar : `${niche.proof.ar}.`),
        beat("cta", "40–50", "الدعوة", "إذا وفّر هذا عليك تخمينًا، اشترك. الحلقة القادمة نطبّق الخطوة على مثال ثاني."),
      ];
    }
    return [
      beat("hook", "0:00", "الخطاف", idea.hook),
      beat("stakes", "0:15", "لماذا يهم", `تأجيل ${topic} عادةً لأن ${niche.trap.ar}. هذا الفيديو يختصر القرار.`),
      beat("p1", "1:00", "الخطأ", `أولًا: ${niche.trap.ar}. سمِّه بصوت عالٍ حتى يعرفه المشاهد في نفسه.`),
      beat("p2", "3:00", "الخطوة", `ثانيًا: ${niche.firstStep.ar}. هذه أصغر نسخة يمكن إنهاؤها اليوم.`),
      beat("p3", "5:30", "الدليل", `ثالثًا: ${niche.proof.ar}.`),
      beat("end", "7:30", "الخلاصة", "أعد الثلاث نقاط في عشرين ثانية، ثم اسأل: أيها ستجرب هذا الأسبوع؟ أشر إلى فيديو تالٍ."),
    ];
  }
  if (idea.format === "short") {
    return [
      beat("hook", "0–3", "Hook", idea.hook),
      beat("promise", "3–8", "Promise", `Stay, and you leave with one step on ${topic}: ${niche.firstStep.en}.`),
      beat("point", "8–25", "Point", `The common trap is ${niche.trap.en}. Reverse it today. Do not add a second topic.`),
      beat("example", "25–40", "Example", niche.proof.en),
      beat("cta", "40–50", "Ask", "If this saved you a guess, subscribe. Next time we run the step on a second example."),
    ];
  }
  return [
    beat("hook", "0:00", "Hook", idea.hook),
    beat("stakes", "0:15", "Why it matters", `People delay ${topic} because of ${niche.trap.en}. This video shortens the decision.`),
    beat("p1", "1:00", "The mistake", `First: ${niche.trap.en}. Name it out loud so the viewer recognizes it.`),
    beat("p2", "3:00", "The step", `Second: ${niche.firstStep.en}. This is the smallest version that can be finished today.`),
    beat("p3", "5:30", "The proof", `Third: ${niche.proof.en}.`),
    beat("end", "7:30", "Close", "Restate the three points in twenty seconds, then ask which one they will try this week. Point to a next video."),
  ];
}

export function buildTags(idea: Pick<Idea, "lang" | "format" | "topic">, niche: Niche) {
  const words = idea.topic
    .split(/\s+/)
    .map((word) => word.replace(/[^\p{L}\p{N}]/gu, ""))
    .filter((word) => word.length > 2);
  const formatTag =
    idea.format === "short"
      ? idea.lang === "ar"
        ? "فيديوهات قصيرة"
        : "shorts"
      : idea.lang === "ar"
        ? "شرح طويل"
        : "long form";
  const base = [...niche.tags[idea.lang], formatTag, ...words];
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const tag of base) {
    const key = tag.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    tags.push(tag);
    if (tags.length === 8) break;
  }
  return tags;
}

export function buildDescription(idea: Pick<Idea, "lang" | "title" | "hook" | "format" | "topic">, niche: Niche, beats: Beat[]) {
  if (idea.lang === "ar") {
    const lines = [
      idea.title,
      "",
      idea.hook,
      "",
      `هذا الفيديو لمبتدئ في ${niche.name.ar}. الخطوة المطلوبة اليوم: ${niche.firstStep.ar}.`,
      "",
      "اشترك إذا أردت الجزء التالي على نفس الموضوع، لا قائمة نصائح عامة.",
    ];
    if (idea.format === "long") {
      lines.push("", "الفصول:");
      for (const item of beats) lines.push(`${item.seconds} ${item.label}`);
    }
    return lines.join("\n");
  }
  const lines = [
    idea.title,
    "",
    idea.hook,
    "",
    `This is for a beginner in ${niche.name.en}. The step for today: ${niche.firstStep.en}.`,
    "",
    "Subscribe if you want the next part on the same topic, not a generic tips list.",
  ];
  if (idea.format === "long") {
    lines.push("", "Chapters:");
    for (const item of beats) lines.push(`${item.seconds} ${item.label}`);
  }
  return lines.join("\n");
}

export function projectDraftFromIdea(idea: Idea): Omit<Project, "id"> {
  const niche = nicheById(idea.niche);
  const beats = buildBeats(idea, niche);
  const line = THUMB_LINES[idea.title.length % THUMB_LINES.length] ?? niche.thumb;
  return {
    ideaId: idea.id,
    title: idea.title,
    topic: idea.topic,
    format: idea.format,
    niche: idea.niche,
    lang: idea.lang,
    hook: idea.hook,
    beats,
    thumbText: wordCount(line[idea.lang]) <= 4 ? line[idea.lang] : niche.thumb[idea.lang],
    description: buildDescription(idea, niche, beats),
    tags: buildTags(idea, niche),
    checklist: emptyMap(PUBLISH_CHECKS),
    film: emptyMap(FILM_CHECKS),
    status: "draft",
    createdAt: new Date().toISOString(),
  };
}

export function checkedCount(map: Record<string, boolean>) {
  return Object.values(map).filter(Boolean).length;
}

export function nextStepId(project: Project): StepId {
  if (project.status === "published") return "done";
  if (scoreTitle(project.title, project.lang).score < 65) return "title";
  if (project.beats.some((item) => item.body.trim().length < 24)) return "script";
  const words = wordCount(project.thumbText);
  if (words === 0 || words > 4) return "thumb";
  if (checkedCount(project.film) < 4) return "film";
  if (checkedCount(project.checklist) < 6) return "pack";
  return "filmgo";
}

export function dayIndex(date = new Date()) {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  return Math.floor(diff / 86400000);
}

export function planDays(perWeek: 1 | 2 | 3) {
  if (perWeek === 1) return [4];
  if (perWeek === 2) return [1, 4];
  return [0, 2, 4];
}

export const WEEKDAYS: Record<Lang, string[]> = {
  ar: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"],
  en: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
};

export function growthInsight(projects: Project[], lang: Lang) {
  const published = projects.filter((item) => item.status === "published");
  if (!published.length) {
    return lang === "ar"
      ? "بعد أول نشر، ارجع خلال يومين واكتب عدد المشاهدات. القرار التالي يعتمد على رقم."
      : "After the first upload, come back within two days and write the view count. The next decision needs a number.";
  }
  const withViews = published.filter((item) => (item.views ?? 0) > 0);
  if (!withViews.length) {
    return lang === "ar"
      ? "الفيديو منشور والرقم ما زال فارغًا. المشاهدات بعد ٤٨ ساعة تكفي لتعرف إن كان الخطاف يعمل."
      : "The video is up and the number is still empty. Views after 48 hours are enough to see if the hook works.";
  }
  const best = [...withViews].sort((a, b) => (b.views ?? 0) - (a.views ?? 0))[0];
  if (!best) return "";
  return lang === "ar"
    ? `الأعلى حتى الآن: «${best.title}». الجزء التالي بنفس الوعد، لا بموضوع جديد.`
    : `Highest so far: “${best.title}”. The next part keeps that promise. It does not open a new topic.`;
}

export function nicheChoices() {
  return NICHES;
}
