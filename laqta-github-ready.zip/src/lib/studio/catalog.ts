import type { L10n, Lang, NicheId } from "./types";

export type Niche = {
  id: NicheId;
  name: L10n;
  blurb: L10n;
  tip: L10n;
  topics: Record<Lang, string[]>;
  trap: L10n;
  firstStep: L10n;
  proof: L10n;
  tags: Record<Lang, string[]>;
  thumb: L10n;
};

export const NICHES: Niche[] = [
  {
    id: "explain",
    name: { ar: "شرح وتبسيط", en: "Explainers" },
    blurb: { ar: "فكرة صعبة بلغة بسيطة", en: "Hard ideas in plain words" },
    tip: { ar: "اشرح فكرة واحدة فقط. الجملة الثانية التي تضيف محورًا جديدًا احذفها.", en: "One idea only. Cut any second sentence that opens a new topic." },
    topics: {
      ar: ["المذاكرة", "التركيز القصير", "شرح الأفكار", "القراءة بفهم", "التعلم بلا ملل", "تدوين الملاحظات"],
      en: ["studying so it sticks", "short-burst focus", "explaining hard ideas", "reading for retention", "learning without burnout", "note-taking that works"],
    },
    trap: { ar: "محاولة شرح كل شيء في فيديو واحد", en: "trying to explain everything in one video" },
    firstStep: { ar: "جملة واحدة يفهمها شخص لا يعرف الموضوع", en: "one sentence a newcomer can repeat" },
    proof: { ar: "خذ مصطلحًا واحدًا واشرحه بمثال من الحياة، لا بتعريف القاموس", en: "define one term with a life example, not a dictionary line" },
    tags: { ar: ["شرح", "تبسيط", "تعلم", "للمبتدئين"], en: ["explainer", "beginners", "learn", "how to"] },
    thumb: { ar: "افهمها بسرعة", en: "Get it fast" },
  },
  {
    id: "stories",
    name: { ar: "قصص", en: "Stories" },
    blurb: { ar: "حكاية قصيرة وفيها درس", en: "A short story with a point" },
    tip: { ar: "ابدأ من لحظة التوتر، لا من «في يوم من الأيام».", en: "Start at the tense moment, not at “once upon a time.”" },
    topics: {
      ar: ["قرار صعب", "عادة صغيرة", "فشل أول", "مقارنة النفس", "اعتذار متأخر", "فرصة ضاعت"],
      en: ["a hard decision", "a tiny habit", "a first failure", "comparing yourself", "a late apology", "a missed chance"],
    },
    trap: { ar: "سرد طويل قبل أن نعرف لماذا تهمنا القصة", en: "a long setup before we know why the story matters" },
    firstStep: { ar: "جملة الصراع في أول ثلاث ثوانٍ", en: "the conflict in the first three seconds" },
    proof: { ar: "تفصيلة حسية واحدة: مكان، جملة قيلت، أو رقم", en: "one sensory detail: a place, a sentence, or a number" },
    tags: { ar: ["قصص", "عبرة", "حكاية", "تحفيز"], en: ["storytime", "lessons", "story", "motivation"] },
    thumb: { ar: "اللحظة الحاسمة", en: "The moment" },
  },
  {
    id: "gaming",
    name: { ar: "ألعاب", en: "Gaming" },
    blurb: { ar: "خطأ واحد ثم التصحيح", en: "One mistake, then the fix" },
    tip: { ar: "اعرض اللعب الخاطئ ثم الصحيح. الكلام وحده لا يُشاهد.", en: "Show the wrong play, then the right one. Talk alone will not hold." },
    topics: {
      ar: ["بداية اللعبة", "إعدادات التصويب", "التمركز", "اقتصاد الجولة", "التدريب القصير", "قراءة الخصم"],
      en: ["the early game", "aim settings", "positioning", "round economy", "short practice", "reading opponents"],
    },
    trap: { ar: "نصائح عامة بلا لقطة من داخل اللعبة", en: "generic tips with no in-game clip" },
    firstStep: { ar: "خطأ واحد يظهر على الشاشة ثم تصحيحه", en: "one on-screen mistake, then the correction" },
    proof: { ar: "خمس ثوانٍ للخطأ وخمس للتصحيح، بلا مقدمة", en: "five seconds of the mistake, five of the fix, no intro" },
    tags: { ar: ["ألعاب", "نصائح", "قيمنق", "للمبتدئين"], en: ["gaming", "tips", "beginner", "gameplay"] },
    thumb: { ar: "هذا الخطأ", en: "This mistake" },
  },
  {
    id: "food",
    name: { ar: "طبخ", en: "Cooking" },
    blurb: { ar: "أكل البيت بمكونات قليلة", en: "Home food, few ingredients" },
    tip: { ar: "اعرض المكونات قبل النار. المشاهد يقرر البقاء في ثانيتين.", en: "Show the ingredients before the heat. Viewers decide in two seconds." },
    topics: {
      ar: ["وجبة سريعة", "تتبيلة واحدة", "الرز المضبوط", "بيض بعدة أشكال", "غداء المكتب", "تحلية بلا فرن"],
      en: ["a fast meal", "one marinade", "rice that works", "eggs a few ways", "a desk lunch", "a no-oven dessert"],
    },
    trap: { ar: "وصفة بعشرين مكونًا لا يملكها المشاهد", en: "a twenty-ingredient recipe nobody has" },
    firstStep: { ar: "ثلاث مكونات موجودة أصلًا في البيت", en: "three ingredients already at home" },
    proof: { ar: "لقطة المكونات مصفوفة، ثم النتيجة في الطبق", en: "a flat-lay of ingredients, then the plated result" },
    tags: { ar: ["طبخ", "وصفات", "أكل", "سهل"], en: ["cooking", "recipe", "easy food", "home cooking"] },
    thumb: { ar: "٣ مكونات", en: "3 ingredients" },
  },
  {
    id: "fitness",
    name: { ar: "لياقة", en: "Fitness" },
    blurb: { ar: "حركة واضحة بلا معدات", en: "Clear movement, no gear" },
    tip: { ar: "صوّر الحركة كاملة من زاوية واحدة. القطع السريع يخفي التمرين.", en: "Film the full move from one angle. Fast cuts hide the exercise." },
    topics: {
      ar: ["تمرين البيت", "ثبات أسبوعين", "ألم الركبة", "المشي السريع", "تمارين الظهر", "عادة الصباح"],
      en: ["home workouts", "a two-week streak", "knee-friendly training", "brisk walking", "back-friendly moves", "a morning habit"],
    },
    trap: { ar: "روتين طويل لا يستطيع المبتدئ إكماله", en: "a long routine a beginner will not finish" },
    firstStep: { ar: "حركة واحدة تُؤدّى ببطء مع تنبيه الخطأ الشائع", en: "one move, done slowly, with the common fault called out" },
    proof: { ar: "اعرض الحركة الخاطئة ثم الصحيحة بجسمك أنت", en: "show the wrong form, then the right form, on your body" },
    tags: { ar: ["لياقة", "تمرين", "بيت", "مبتدئ"], en: ["fitness", "workout", "home", "beginner"] },
    thumb: { ar: "١٢ دقيقة", en: "12 minutes" },
  },
  {
    id: "money",
    name: { ar: "مال", en: "Money" },
    blurb: { ar: "راتب، صرف، وقرارات صغيرة", en: "Pay, spending, small decisions" },
    tip: { ar: "لا توصِ باستثمار. علّم تتبع مبلغ واحد هذا الأسبوع.", en: "Do not recommend investments. Teach tracking one amount this week." },
    topics: {
      ar: ["ميزانية الراتب", "مصاريف صغيرة", "الديون القصيرة", "صندوق الطوارئ", "مقارنة الأسعار", "عادة الادخار"],
      en: ["a paycheck budget", "small leaks", "short-term debt", "an emergency buffer", "comparing prices", "a saving habit"],
    },
    trap: { ar: "وعود بالثراء أو نصيحة استثمار بلا سياق", en: "get-rich promises or investment tips with no context" },
    firstStep: { ar: "كتابة كل صرف لثلاثة أيام فقط", en: "writing down every spend for three days only" },
    proof: { ar: "رقم حقيقي من أسبوعك، مع إخفاء ما يلزم خصوصيتك", en: "a real number from your week, with private details hidden" },
    tags: { ar: ["مال", "ميزانية", "توفير", "مبتدئ"], en: ["money", "budget", "saving", "personal finance"] },
    thumb: { ar: "أين يذهب", en: "Where it goes" },
  },
  {
    id: "tech",
    name: { ar: "تقنية", en: "Tech" },
    blurb: { ar: "إعداد أو أداة تنفع اليوم", en: "A setting or tool for today" },
    tip: { ar: "سجّل الشاشة والإصبع. لا تتكلم عن الزر دون أن نراه.", en: "Record the screen and your finger. Do not describe a button we cannot see." },
    topics: {
      ar: ["بطء الهاتف", "حماية الحساب", "النسخ الاحتياطي", "ترتيب الصور", "اختصارات مفيدة", "أداة مجانية"],
      en: ["a slow phone", "account safety", "backups", "photo clutter", "useful shortcuts", "a free tool"],
    },
    trap: { ar: "مصطلحات كثيرة قبل أن نرى الخطوة على الشاشة", en: "jargon before we see the step on screen" },
    firstStep: { ar: "نقرة واحدة نراها، ثم نتيجتها فورًا", en: "one visible tap, then the result immediately" },
    proof: { ar: "قبل وبعد على نفس الشاشة", en: "before and after on the same screen" },
    tags: { ar: ["تقنية", "هاتف", "شرح", "نصائح"], en: ["tech", "phone", "tutorial", "tips"] },
    thumb: { ar: "أوقف هذا", en: "Turn this off" },
  },
  {
    id: "reviews",
    name: { ar: "مراجعات", en: "Reviews" },
    blurb: { ar: "حكم صريح بعد تجربة", en: "A straight verdict after use" },
    tip: { ar: "قل لمن لا يناسبه المنتج. هذا ما يبني الثقة.", en: "Say who it is not for. That is what builds trust." },
    topics: {
      ar: ["سماعات يومية", "أداة مطبخ", "تطبيق مجاني", "كتاب مشهور", "كرسي مكتب", "منتج فيروسي"],
      en: ["everyday headphones", "a kitchen tool", "a free app", "a famous book", "a desk chair", "a viral product"],
    },
    trap: { ar: "مدح عام يشبه الإعلان", en: "generic praise that sounds like an ad" },
    firstStep: { ar: "الحكم في أول جملة: يستحق، أو لا، ولمن", en: "the verdict in sentence one: worth it or not, and for whom" },
    proof: { ar: "عيب واحد حقيقي استخدمته أسبوعًا", en: "one real flaw after a week of use" },
    tags: { ar: ["مراجعة", "تجربة", "شراء", "رأي"], en: ["review", "worth it", "tested", "opinion"] },
    thumb: { ar: "لا تشتريه", en: "Skip it" },
  },
  {
    id: "daily",
    name: { ar: "يوميات", en: "Daily life" },
    blurb: { ar: "يوم عادي وفيه ملاحظة", en: "An ordinary day with a point" },
    tip: { ar: "اليوميات تعمل حين فيها تحول صغير، لا حين تكون جدولًا.", en: "A daily vlog works when something small changes, not when it is a schedule." },
    topics: {
      ar: ["روتين الصباح", "يوم بلا تجميل", "ترتيب غرفة", "عادة واحدة", "يوم انقلب", "مشي المساء"],
      en: ["a morning routine", "an unpolished day", "resetting a room", "one habit", "a day that flipped", "an evening walk"],
    },
    trap: { ar: "تصوير كل شيء بلا سبب للمشاهدة", en: "filming everything with no reason to watch" },
    firstStep: { ar: "جملة في البداية تقول ماذا سيتغير آخر اليوم", en: "an opening line that says what will be different by the end" },
    proof: { ar: "لقطة قبل ولقطة بعد لنفس المكان أو العادة", en: "a before and after of the same place or habit" },
    tags: { ar: ["يوميات", "روتين", "حياة", "فلوق"], en: ["vlog", "routine", "day in the life", "daily"] },
    thumb: { ar: "يوم حقيقي", en: "A real day" },
  },
  {
    id: "values",
    name: { ar: "قيم يومية", en: "Daily values" },
    blurb: { ar: "خلق يُمارس اليوم لا يُحاضر", en: "A value you practice today" },
    tip: { ar: "لا تَعِظ. احكِ ماذا فعلت اليوم حين صعب عليك الخلق.", en: "Do not preach. Tell what you did today when the value was hard." },
    topics: {
      ar: ["الامتنان العملي", "الاعتذار", "حفظ الوقت", "حسن الظن", "الصدق اللطيف", "الصبر القصير"],
      en: ["practical gratitude", "apologizing well", "guarding time", "fair assumptions", "kind honesty", "short-term patience"],
    },
    trap: { ar: "محاضرة عامة بلا موقف حدث فعلًا", en: "a general lecture with no real moment" },
    firstStep: { ar: "موقف من هذا الأسبوع في أربع جمل", en: "a moment from this week in four sentences" },
    proof: { ar: "الخطوة التي ستعملها اليوم بعد إغلاق الفيديو", en: "the step you will take today after the video ends" },
    tags: { ar: ["قيم", "عادات", "تطوير", "يوميات"], en: ["values", "habits", "character", "daily practice"] },
    thumb: { ar: "اليوم فقط", en: "Just today" },
  },
];

export const PATTERNS: { text: L10n; why: L10n; mid?: boolean }[] = [
  {
    text: {
      ar: "لا تبدأ {topic} قبل أن تشاهد هذا",
      en: "Don't start {topic} until you watch this",
    },
    why: {
      ar: "يمنع البداية العشوائية. المبتدئ يبحث عن إذن واضح لا عن موسوعة.",
      en: "It blocks a random start. Beginners want a clear permission, not an encyclopedia.",
    },
  },
  {
    text: {
      ar: "{n} أخطاء في {topic} يقع فيها المبتدئ",
      en: "{n} beginner mistakes in {topic}",
    },
    why: {
      ar: "قائمة قصيرة تعطي سببًا للبقاء حتى آخر خطأ.",
      en: "A short list gives a reason to stay through the last mistake.",
    },
  },
  {
    text: {
      ar: "{topic} خلال {mins} دقائق للمبتدئ",
      en: "{topic} in {mins} minutes for beginners",
    },
    why: {
      ar: "الوعد الزمني يقلل التردد. الناس تقرر في ثانيتين.",
      en: "A time promise lowers hesitation. People decide in two seconds.",
    },
  },
  {
    mid: true,
    text: {
      ar: "جرّبت {topic} لأسبوع وهذه النتيجة",
      en: "I tried {topic} for a week. Here is the result",
    },
    why: {
      ar: "التجربة أقوى من النصيحة، بشرط أن تذكر النتيجة لا شعورك فقط.",
      en: "A trial beats advice, if you state the result and not only the feeling.",
    },
  },
  {
    text: {
      ar: "الحقيقة عن {topic} التي لا تُقال",
      en: "The plain truth about {topic}",
    },
    why: {
      ar: "تعمل فقط إذا كسرت اعتقادًا شائعًا بجملة محددة، لا بعنوان فضفاض.",
      en: "It works only if you break a common belief with a specific line, not a vague title.",
    },
  },
  {
    text: {
      ar: "أسهل مدخل إلى {topic} بدون تعقيد",
      en: "The easiest way into {topic} without the fluff",
    },
    why: {
      ar: "يخاطب من يخاف أن الموضوع أكبر منه.",
      en: "It speaks to someone afraid the topic is too big for them.",
    },
  },
];

export const HOOKS: L10n[] = [
  {
    ar: "قبل أن تجرب {topic}، في غلطة واحدة تعيدك إلى البداية.",
    en: "Before you try {topic}, one mistake sends you back to the start.",
  },
  {
    ar: "إذا كان {topic} يربكك، هذه الدقيقة توفر عليك أسبوع تخمين.",
    en: "If {topic} confuses you, this minute saves a week of guessing.",
  },
  {
    ar: "لن أعطيك قائمة طويلة. خطوة واحدة في {topic} تطبقها اليوم.",
    en: "No long list. One step in {topic} you can do today.",
  },
  {
    ar: "كنت أتعامل مع {topic} مثل الجميع، ثم توقفت عن هذا.",
    en: "I handled {topic} like everyone else. Then I stopped doing this.",
  },
  {
    ar: "ثلاث علامات أن طريقتك في {topic} لن تنفع.",
    en: "Three signs your way of doing {topic} will not work.",
  },
];

export const THUMB_LINES: L10n[] = [
  { ar: "لا تبدأ هكذا", en: "Not like this" },
  { ar: "٣ أخطاء", en: "3 mistakes" },
  { ar: "في دقائق", en: "In minutes" },
  { ar: "بعد أسبوع", en: "After a week" },
  { ar: "الحقيقة", en: "The truth" },
  { ar: "بدون تعقيد", en: "No fluff" },
];

export const PUBLISH_CHECKS: { id: string; text: L10n }[] = [
  { id: "read-title", text: { ar: "العنوان يُقرأ بصوت عالٍ في أقل من ٤ ثوانٍ", en: "The title can be read aloud in under 4 seconds" } },
  { id: "hook-early", text: { ar: "الخطاف في أول ٥ ثوانٍ، لا بعد تحية أو مقدمة", en: "The hook is in the first 5 seconds, not after a hello" } },
  { id: "thumb-words", text: { ar: "نص الصورة ٤ كلمات أو أقل ويُقرأ وأنت مغمض نصف عينك", en: "Thumbnail text is 4 words or fewer and readable at a glance" } },
  { id: "thumb-contrast", text: { ar: "عنصر واحد واضح من بعيد: وجه، يد، أو نتيجة", en: "One element reads from far away: face, hand, or result" } },
  { id: "description", text: { ar: "الوصف فيه خلاصة الفيديو ودعوة للاشتراك بجملة", en: "The description has a summary and a one-line subscribe ask" } },
  { id: "tags", text: { ar: "خمسة وسوم على الأقل، وفيها كلمة يبحث عنها مبتدئ", en: "At least five tags, including a phrase a beginner would search" } },
  { id: "no-repeat", text: { ar: "الصورة لا تنسخ العنوان حرفيًا", en: "The thumbnail does not copy the title word for word" } },
  { id: "ending", text: { ar: "النهاية سؤال أو فيديو تالٍ، لا وداع طويل", en: "The ending is a question or a next video, not a long goodbye" } },
];

export const FILM_CHECKS: { id: string; text: L10n }[] = [
  { id: "light", text: { ar: "الضوء أمام الوجه من نافذة، وليس خلفك", en: "Light hits the face from a window, not from behind you" } },
  { id: "stable", text: { ar: "الهاتف ثابت. الاهتزاز يبدو غير واثق", en: "The phone is stable. Shake reads as uncertainty" } },
  { id: "audio", text: { ar: "الصوت قريب: سماعة سلكية أو الجهاز على بعد ذراع", en: "Sound is close: wired earphones or the device within arm's reach" } },
  { id: "takes", text: { ar: "الخطاف سُجّل ثلاث مرات واخترت الأقوى", en: "The hook was recorded three times and you picked the strongest" } },
  { id: "single", text: { ar: "أثناء التصوير لم تُضف فكرة ثانية", en: "You did not add a second idea while filming" } },
];

export const GUIDE: { id: string; title: L10n; body: Record<Lang, string[]> }[] = [
  {
    id: "month",
    title: { ar: "أول ٣٠ يومًا", en: "The first 30 days" },
    body: {
      ar: [
        "لا تغيّر الموضوع قبل ٨ فيديوهات. التبديل المبكر يمنعك من معرفة ما ينجح.",
        "اختر شكلًا واحدًا هذا الشهر: قصير أو طويل. الخلط قبل أن تتقن الخطاف يشتت مجهودك.",
        "اليوم الثابت أهم من «الجودة السينمائية». فيديو متوسط في موعده يعلّمك أسرع من فيديو مثالي يتأجل.",
        "الجودة في البداية = صوت مفهوم + فكرة واحدة. المونتاج الثقيل لا يصلح خطافًا ضعيفًا.",
      ],
      en: [
        "Do not switch topics before 8 videos. Early switching hides what is working.",
        "Pick one shape this month: short or long. Mixing before the hook is reliable splits your effort.",
        "A fixed day beats cinematic quality. An average video on time teaches faster than a perfect one that slips.",
        "Early quality means intelligible sound and one idea. Heavy editing cannot rescue a weak hook.",
      ],
    },
  },
  {
    id: "mistakes",
    title: { ar: "أخطاء توقف القناة", en: "Mistakes that stall a channel" },
    body: {
      ar: [
        "مقدمة «أهلًا بكم في قناتي» قبل أن تقول الفائدة. المشاهد الجديد لا يعرفك ولا يدين لك بالانتظار.",
        "عنوان بلا نتيجة: كلمات كبيرة مثل «كل شيء عن» من غير وعد محدد.",
        "صورة فيها فقرة. إن لم تُقرأ بحجم الظفر فهي غير موجودة.",
        "مقارنة قناتك في أسبوعها الأول بقناة عمرها سنوات، ثم التوقف.",
        "شراء مشتركين أو مشاهدات. الرقم الكاذب يفسد ما يتعلمه يوتيوب عن جمهورك الحقيقي.",
      ],
      en: [
        "A “welcome to my channel” before the payoff. A new viewer does not owe you the wait.",
        "A title with no result: big words like “everything about” and no specific promise.",
        "A paragraph on the thumbnail. If it fails at thumbnail size, it is not there.",
        "Comparing week one with a channel that is years old, then quitting.",
        "Buying subscribers or views. Fake numbers teach YouTube the wrong audience.",
      ],
    },
  },
  {
    id: "hooks",
    title: { ar: "معادلات الخطاف", en: "Hook formulas" },
    body: {
      ar: [
        "تحذير ثم نتيجة: «قبل أن تفعل هذا، غلطة واحدة تعيدك للبداية.»",
        "رقم محدد ثم وعد: «ثلاث علامات» أو «خلال دقيقة» أفضل من «أشياء مهمة».",
        "كنت أفعل مثل الجميع ثم توقفت: اعترف بالعادة، ثم سمِّ ما تركته.",
        "اكتب خمسة خطافات واقرأها لشخص. إذا لم يقل «وبعدين؟» أعد الكتابة.",
        "الخطاف ليس تحية وليس شعار القناة. هو سبب البقاء حتى الثانية السادسة.",
      ],
      en: [
        "Warning, then result: “Before you do this, one mistake sends you back.”",
        "A specific number, then a promise: “three signs” or “in a minute” beats “important things.”",
        "I used to do it like everyone, then I stopped: name the habit, then name what you dropped.",
        "Write five hooks and read them to someone. If they do not ask “then what?”, rewrite.",
        "A hook is not a greeting and not a channel slogan. It is the reason to stay past second six.",
      ],
    },
  },
  {
    id: "thumb",
    title: { ar: "الصورة المصغّرة", en: "Thumbnails" },
    body: {
      ar: [
        "أربع كلمات كحد أقصى. الكلمة الزائدة تُحذف لا تُصغَّر.",
        "تباين واضح: عنصر فاتح على خلفية أغمق، أو العكس. الزحمة تختفي في الرئيسية.",
        "وجه أو يد أو نتيجة. الشعار وحده لا يُنقر في البداية.",
        "لا تكرر العنوان حرفيًا. الصورة تقول الزاوية، والعنوان يقول الوعد.",
        "صغّرها على هاتفك قبل الرفع. إن احتجت أن تقرّب، أعد التصميم.",
      ],
      en: [
        "Four words maximum. An extra word gets cut, not shrunk.",
        "Clear contrast: a light subject on a darker ground, or the reverse. Clutter disappears on the home feed.",
        "A face, a hand, or a result. A logo alone will not earn the click yet.",
        "Do not copy the title. The image carries the angle; the title carries the promise.",
        "Shrink it on your phone before upload. If you have to zoom, redesign.",
      ],
    },
  },
  {
    id: "algo",
    title: { ar: "يوتيوب بلغة بسيطة", en: "YouTube in plain language" },
    body: {
      ar: [
        "الفيديو يُجرَّب أولًا على مجموعة صغيرة. إذا شاهدوا وبقي جزء منهم، تتسع التجربة.",
        "لذلك الخطاف وإكمال المشاهدة أهم من البحث عن «ساعة سحرية» للنشر.",
        "التعليقات في الساعات الأولى إشارة مفيدة، ليست طقسًا. رد باختصار ثم عد للتصوير.",
        "لا يوجد عقاب على النية الحسنة ولا مكافأة على المعاناة. المكافأة لمن يُبقي الناس.",
        "سلسلة من أربع حلقات على نفس الزاوية تعلّم المنصة أسرع من ثمانية مواضيع مختلفة.",
      ],
      en: [
        "A video is tested on a small group first. If they watch and some stay, the test widens.",
        "That is why the hook and watch-through matter more than hunting a magic upload hour.",
        "Early comments are a useful signal, not a ritual. Reply briefly, then go film.",
        "There is no punishment for good intentions and no prize for suffering. The prize is for keeping people.",
        "A four-video series on one angle teaches the platform faster than eight unrelated topics.",
      ],
    },
  },
  {
    id: "gear",
    title: { ar: "ابدأ بما عندك", en: "Start with what you have" },
    body: {
      ar: [
        "هاتف حديث يكفي لأول عشرين فيديو. الكاميرا لا تصلح فكرة ضعيفة.",
        "نافذة أمام الوجه أفضل من حلقة إضاءة تُشترى قبل أول نشر.",
        "سماعة سلكية أقرب ميكروفون تملكه غالبًا. ضعها بحيث لا تحتك بالملابس.",
        "ثبّت الهاتف بكتب أو حامل رخيص. الصورة الثابتة تبدو أقرب للاحتراف من كاميرا تهتز.",
        "للقص: CapCut أو YouTube Create. لا تؤجل النشر لأنك لم تتعلم برنامجًا معقدًا.",
      ],
      en: [
        "A recent phone is enough for the first twenty videos. A camera will not fix a weak idea.",
        "A window in front of the face beats a ring light bought before the first upload.",
        "Wired earphones are often the closest microphone you own. Keep them from rubbing on clothes.",
        "Brace the phone with books or a cheap stand. A still frame looks more capable than a shaking camera.",
        "Cut in CapCut or YouTube Create. Do not delay a publish to learn a complex editor.",
      ],
    },
  },
];

export const DAILY: Record<Lang, string[]> = {
  ar: [
    "اكتب الخطاف قبل أن تفتح الكاميرا. التصوير ليس وقت التفكير.",
    "إن لم تستطع قول العنوان في نفس واحد، فهو طويل.",
    "الفيديو الأول هدفه أن يُنشر، لا أن يمثّلك لخمس سنوات.",
    "احذف التحية. ابدأ من الغلطة أو من النتيجة.",
    "صوّر الخطاف واقفًا أقرب مما ترتاح. القرب يصنع حضورًا.",
    "لا تفتح التعليقات السلبية قبل أن تجدول فيديو الغد.",
    "وسْم واحد يبحث عنه مبتدئ أفضل من عشرة وسوم عامة.",
    "إن انتهيت من التصوير وما زلت تشرح فكرتين، اقطع واحدة في المونتاج.",
  ],
  en: [
    "Write the hook before you open the camera. Filming is not the time to think.",
    "If you cannot say the title in one breath, it is too long.",
    "The first video exists to be published, not to represent you for five years.",
    "Delete the greeting. Start from the mistake or the result.",
    "Film the hook standing closer than feels comfortable. Proximity reads as presence.",
    "Do not open harsh comments before tomorrow’s video is scheduled.",
    "One tag a beginner would search beats ten generic tags.",
    "If you finished filming and you are still explaining two ideas, cut one in the edit.",
  ],
};

export const MILESTONES: { id: string; metric: "videos" | "subs"; n: number; title: L10n; body: L10n }[] = [
  {
    id: "v1",
    metric: "videos",
    n: 1,
    title: { ar: "أول فيديو", en: "First video" },
    body: { ar: "النشر أهم من الإتقان. بعد رفعه، اكتب ماذا ستكرر لا ماذا تخجل منه.", en: "Shipping beats polish. After upload, write what you will repeat, not what you are ashamed of." },
  },
  {
    id: "v4",
    metric: "videos",
    n: 4,
    title: { ar: "أربعة فيديوهات", en: "Four videos" },
    body: { ar: "صار عندك نمط. انظر أي عنوان فيه رقم أو نتيجة، واصنع الجزء التالي منه.", en: "You have a pattern. Find the title with a number or a result, and make the next part from that." },
  },
  {
    id: "v8",
    metric: "videos",
    n: 8,
    title: { ar: "ثمانية فيديوهات", en: "Eight videos" },
    body: { ar: "ثبّت يومًا واحدًا في الأسبوع. لا تغيّر الموضوع قبل أن تكرر الزاوية الأفضل مرتين.", en: "Lock one day a week. Do not change topics before you repeat the best angle twice." },
  },
  {
    id: "s100",
    metric: "subs",
    n: 100,
    title: { ar: "١٠٠ مشترك", en: "100 subscribers" },
    body: { ar: "رد على التعليقات خلال يوم. هؤلاء أول من يشعر أن القناة لشخص حقيقي.", en: "Reply to comments within a day. These are the first people who feel a real person is here." },
  },
  {
    id: "s1000",
    metric: "subs",
    n: 1000,
    title: { ar: "١٠٠٠ مشترك", en: "1,000 subscribers" },
    body: { ar: "ابدأ سلسلة من أربع حلقات على الزاوية الأعلى مشاهدة. لا تفتتح موضوعًا جديدًا احتفالًا.", en: "Start a four-part series on the highest-viewed angle. Do not open a new topic as a celebration." },
  },
];

export function nicheById(id: NicheId): Niche {
  return NICHES.find((n) => n.id === id) ?? NICHES[0];
}
