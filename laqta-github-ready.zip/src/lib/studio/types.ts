export type Lang = "ar" | "en";
export type NicheId =
  | "explain"
  | "stories"
  | "gaming"
  | "food"
  | "fitness"
  | "money"
  | "tech"
  | "reviews"
  | "daily"
  | "values";

export type Format = "short" | "long";
export type Cadence = Format | "mix";
export type L10n = Record<Lang, string>;

export type Idea = {
  id: string;
  niche: NicheId;
  format: Format;
  lang: Lang;
  topic: string;
  title: string;
  hook: string;
  why: string;
  minutes: number;
  difficulty: "easy" | "mid";
  saved: boolean;
};

export type Beat = {
  id: string;
  seconds: string;
  label: string;
  body: string;
};

export type Project = {
  id: string;
  ideaId?: string;
  title: string;
  topic: string;
  format: Format;
  niche: NicheId;
  lang: Lang;
  hook: string;
  beats: Beat[];
  thumbText: string;
  description: string;
  tags: string[];
  checklist: Record<string, boolean>;
  film: Record<string, boolean>;
  status: "draft" | "published";
  createdAt: string;
  publishedAt?: string;
  views?: number;
  note?: string;
};

export type Profile = {
  channel: string;
  niche: NicheId;
  format: Cadence;
  perWeek: 1 | 2 | 3;
  subsGoal: number;
  subsNow: number;
  lang: Lang;
  onboarded: boolean;
  streak: number;
  lastDay: string | null;
};

export type NavId = "today" | "ideas" | "project" | "growth" | "guide";
export type ProjectTab = "title" | "script" | "thumb" | "pack";
export type StepId = "title" | "script" | "thumb" | "film" | "pack" | "filmgo" | "done";
