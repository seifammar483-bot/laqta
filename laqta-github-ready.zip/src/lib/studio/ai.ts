import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  lang: z.enum(["ar", "en"]),
  niche: z.string().min(1).max(60),
  format: z.enum(["short", "long"]),
  topic: z.string().min(1).max(180),
  title: z.string().max(200),
  hook: z.string().max(500),
});

export type SharpenResult =
  | { ok: true; titles: string[]; hook: string; note: string }
  | { ok: false; error: string };

function parseModel(text: string): { titles: string[]; hook: string; note: string } | null {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const value = JSON.parse(cleaned.slice(start, end + 1)) as {
      titles?: unknown;
      hook?: unknown;
      note?: unknown;
    };
    if (!Array.isArray(value.titles) || typeof value.hook !== "string") return null;
    const titles = value.titles
      .filter((item): item is string => typeof item === "string" && item.trim().length > 0)
      .map((item) => item.trim())
      .slice(0, 3);
    if (!titles.length) return null;
    return {
      titles,
      hook: value.hook.trim(),
      note: typeof value.note === "string" ? value.note.trim() : "",
    };
  } catch {
    return null;
  }
}

export const sharpenCopy = createServerFn({ method: "POST" })
  .validator((input: unknown) => schema.parse(input))
  .handler(async ({ data }): Promise<SharpenResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "unavailable" };
    const langName = data.lang === "ar" ? "Arabic" : "English";
    const prompt = [
      `You help a beginner YouTuber. Reply in ${langName}.`,
      "Return JSON only: {\"titles\":[3 strings],\"hook\":\"one spoken sentence\",\"note\":\"one short reason\"}.",
      "Titles: specific, one promise, a number or time when natural. No 'you won't believe', no all caps, no channel slogans.",
      "Hook: spoken in the first 3 seconds. No hello.",
      `Niche: ${data.niche}`,
      `Format: ${data.format}`,
      `Topic: ${data.topic}`,
      `Current title: ${data.title}`,
      `Current hook: ${data.hook}`,
    ].join("\n");
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.6,
          max_tokens: 420,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      if (!res.ok) return { ok: false, error: `status ${res.status}` };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content ?? "";
      const parsed = parseModel(text);
      if (!parsed) return { ok: false, error: "parse" };
      return { ok: true, ...parsed };
    } catch {
      return { ok: false, error: "network" };
    }
  });
