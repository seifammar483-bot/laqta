import { useMemo, useState } from "react";
import { NICHES } from "@/lib/studio/catalog";
import { copyOf } from "@/lib/studio/copy";
import { makeIdeas } from "@/lib/studio/engine";
import { useStudio } from "@/lib/studio/store";
import type { Cadence, NicheId } from "@/lib/studio/types";
import { Button, LangSwitch, Mark, fieldClass } from "./ui";
import { cn } from "@/lib/utils";

export function Onboarding() {
  const lang = useStudio((s) => s.profile.lang);
  const setLang = useStudio((s) => s.setLang);
  const complete = useStudio((s) => s.completeOnboarding);
  const c = copyOf(lang);
  const [step, setStep] = useState(1);
  const [channel, setChannel] = useState("");
  const [niche, setNiche] = useState<NicheId>("explain");
  const [format, setFormat] = useState<Cadence>("short");
  const [perWeek, setPerWeek] = useState<1 | 2 | 3>(2);
  const [goal, setGoal] = useState(1000);

  const ideas = useMemo(
    () => makeIdeas({ niche, format, lang, seed: 21, count: 4 }),
    [niche, format, lang],
  );
  const lead = ideas[0];

  function finish(name: string) {
    complete({
      channel: name,
      niche,
      format,
      perWeek,
      subsGoal: goal,
      ideas: makeIdeas({ niche, format, lang, seed: 21, count: 4 }),
    });
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="flex items-center justify-between px-4 py-4 md:px-8">
        <div className="flex items-center gap-3">
          <Mark className="size-8" />
          <div>
            <div className="text-lg leading-none">{c.app}</div>
            <div className="mt-1 text-xs text-subtle">{c.studio}</div>
          </div>
        </div>
        <LangSwitch lang={lang} onChange={setLang} ar={c.langAr} en={c.langEn} />
      </header>
      <main className="mx-auto w-full max-w-xl px-4 pb-36 md:px-0">
        <p className="text-sm text-subtle">{c.step(step)}</p>
        {step === 1 && (
          <section className="rise mt-4">
            <h1 className="text-3xl">{c.nameQ}</h1>
            <p className="mt-3 text-muted">{c.nameHint}</p>
            <input
              dir="auto"
              autoFocus
              value={channel}
              onChange={(event) => setChannel(event.target.value)}
              placeholder={c.namePh}
              className={cn(fieldClass, "mt-6 h-12")}
            />
            <h2 className="mt-8 text-xl">{c.nicheQ}</h2>
            <div className="mt-6 grid grid-cols-2 gap-2">
              {NICHES.map((item) => {
                const on = item.id === niche;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setNiche(item.id)}
                    className={cn(
                      "press rounded-xl px-3 py-2 text-start",
                      on ? "bg-accent text-accent-fg" : "border border-line bg-surface text-fg",
                    )}
                  >
                    <div className="text-sm font-medium">{item.name[lang]}</div>
                    <div className={cn("mt-1 line-clamp-2 text-xs", on ? "text-accent-fg/70" : "text-muted")}>
                      {item.blurb[lang]}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        )}
        {step === 2 && (
          <section className="rise mt-4">
            <h1 className="text-3xl">{c.cadenceQ}</h1>
            <p className="mt-3 text-muted">{c.cadenceHint}</p>
            <div className="mt-6 grid grid-cols-3 gap-2">
              {(
                [
                  ["short", c.short],
                  ["long", c.long],
                  ["mix", c.mix],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  aria-pressed={format === id}
                  onClick={() => setFormat(id)}
                  className={cn(
                    "press h-11 rounded-sm text-sm",
                    format === id ? "bg-accent text-accent-fg" : "border border-line bg-surface",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <h2 className="mt-8 text-lg">{c.perWeek}</h2>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {([1, 2, 3] as const).map((n) => (
                <button
                  key={n}
                  type="button"
                  aria-pressed={perWeek === n}
                  onClick={() => setPerWeek(n)}
                  className={cn(
                    "press h-11 rounded-sm text-sm",
                    perWeek === n ? "bg-accent text-accent-fg" : "border border-line bg-surface",
                  )}
                >
                  {c.times(n)}
                </button>
              ))}
            </div>
            <h2 className="mt-8 text-lg">{c.goal}</h2>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {[100, 1000, 10000].map((n) => (
                <button
                  key={n}
                  type="button"
                  aria-pressed={goal === n}
                  onClick={() => setGoal(n)}
                  className={cn(
                    "press h-11 rounded-sm text-sm tabular-nums",
                    goal === n ? "bg-accent text-accent-fg" : "border border-line bg-surface",
                  )}
                >
                  {c.goalN(n)}
                </button>
              ))}
            </div>
          </section>
        )}
        {step === 3 && lead && (
          <section className="rise mt-4">
            <p className="text-sm text-muted">{c.previewKicker}</p>
            <h1 className="mt-3 text-3xl">{lead.title}</h1>
            <p className="mt-4 text-muted">{lead.hook}</p>
            <ul className="mt-6 space-y-2 border-t border-line pt-4">
              <li className="text-xs text-subtle">{c.also}</li>
              {ideas.slice(1, 3).map((idea) => (
                <li key={idea.id} className="text-sm">
                  {idea.title}
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>
      <div className="safe-bottom fixed inset-x-0 bottom-0 z-10 border-t border-line bg-bg">
        <div className="mx-auto flex w-full max-w-xl gap-2 px-4 py-3">
          {step === 1 && (
            <Button variant="line" onClick={() => finish(lang === "ar" ? "ببساطة" : "Plainly")}>
              {c.example}
            </Button>
          )}
          {step > 1 && (
            <Button variant="line" onClick={() => setStep((value) => value - 1)}>
              {c.back}
            </Button>
          )}
          {step < 3 ? (
            <Button className="flex-1" disabled={step === 1 && channel.trim().length < 2} onClick={() => setStep((value) => value + 1)}>
              {c.next}
            </Button>
          ) : (
            <Button className="flex-1" onClick={() => finish(channel)}>
              {c.enter}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
