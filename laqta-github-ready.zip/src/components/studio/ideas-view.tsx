import { useState } from "react";
import { NICHES, nicheById } from "@/lib/studio/catalog";
import type { Copy } from "@/lib/studio/copy";
import { altTitles } from "@/lib/studio/engine";
import { sharpenCopy } from "@/lib/studio/ai";
import { useStudio } from "@/lib/studio/store";
import type { Cadence, Idea, NicheId } from "@/lib/studio/types";
import { Button } from "./ui";
import { cn } from "@/lib/utils";

type Draft = { id: string; titles: string[]; hook: string | null; source: "grok" | "local"; note: string };

export function IdeasView({ c }: { c: Copy }) {
  const profile = useStudio((s) => s.profile);
  const ideas = useStudio((s) => s.ideas);
  const generate = useStudio((s) => s.generateBatch);
  const toggleSave = useStudio((s) => s.toggleSave);
  const apply = useStudio((s) => s.applyIdeaCopy);
  const start = useStudio((s) => s.startProject);
  const [niche, setNiche] = useState<NicheId>(profile.niche);
  const [format, setFormat] = useState<Cadence>(profile.format);
  const [savedOnly, setSavedOnly] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const lang = profile.lang;
  const visible = ideas.filter((idea) => (savedOnly ? idea.saved : true));

  async function stronger(idea: Idea) {
    setBusy(idea.id);
    let titles: string[] = [];
    let hook: string | null = null;
    let source: Draft["source"] = "local";
    let note = "";
    try {
      const result = await sharpenCopy({
        data: {
          lang: idea.lang,
          niche: nicheById(idea.niche).name[idea.lang],
          format: idea.format,
          topic: idea.topic,
          title: idea.title,
          hook: idea.hook,
        },
      });
      if (result.ok) {
        titles = result.titles;
        hook = result.hook;
        source = "grok";
        note = result.note;
      }
    } catch {
      source = "local";
    }
    if (!titles.length) titles = altTitles(idea);
    setDraft({ id: idea.id, titles, hook, source, note });
    setBusy(null);
  }

  return (
    <div className="rise space-y-5">
      <div>
        <h1 className="text-3xl">{c.ideasTitle}</h1>
        <p className="mt-2 text-sm text-muted">{c.ideasHint}</p>
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <select
          value={niche}
          onChange={(event) => setNiche(event.target.value as NicheId)}
          className="h-11 rounded-sm border border-line bg-surface px-3 text-sm"
          aria-label={c.niche}
        >
          {NICHES.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name[lang]}
            </option>
          ))}
        </select>
        <div className="grid flex-1 grid-cols-3 gap-1 rounded-lg bg-surface p-1">
          {(
            [
              ["short", c.short],
              ["long", c.long],
              ["mix", c.mix],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              aria-pressed={format === id}
              onClick={() => setFormat(id)}
              className={cn("press h-9 rounded-sm text-sm", format === id ? "bg-accent text-accent-fg" : "text-muted")}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => generate(niche, format)}>{c.generate}</Button>
        <Button variant={savedOnly ? "primary" : "line"} onClick={() => setSavedOnly((value) => !value)}>
          {c.savedOnly}
        </Button>
      </div>
      <ul className="space-y-3">
        {visible.map((idea) => (
          <li key={idea.id} className="rounded-xl bg-surface p-4">
            <div className="flex flex-wrap gap-2 text-xs text-subtle">
              <span>{nicheById(idea.niche).name[lang]}</span>
              <span>{idea.format === "short" ? c.short : c.long}</span>
              <span>{c.aboutMin(idea.minutes)}</span>
              <span>{idea.difficulty === "easy" ? c.easy : c.mid}</span>
              {idea.lang !== lang && <span>{idea.lang === "ar" ? "عربي" : "EN"}</span>}
            </div>
            <h2 className="mt-3 text-xl">{idea.title}</h2>
            <p className="mt-2 text-sm text-muted">{idea.hook}</p>
            <p className="mt-3 text-sm">
              <span className="text-subtle">{c.why}. </span>
              {idea.why}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button onClick={() => start(idea.id)}>{c.start}</Button>
              <Button variant="line" onClick={() => toggleSave(idea.id)}>
                {idea.saved ? c.savedDone : c.save}
              </Button>
              <Button variant="quiet" disabled={busy === idea.id} onClick={() => stronger(idea)}>
                {busy === idea.id ? c.working : c.alts}
              </Button>
            </div>
            {draft?.id === idea.id && (
              <div className="mt-4 border-t border-line pt-3">
                <p className="text-xs text-subtle">{draft.source === "grok" ? c.altsGrok : c.altsLocal}</p>
                {draft.note && <p className="mt-2 text-sm text-muted">{draft.note}</p>}
                <ul className="mt-3 space-y-2">
                  {draft.titles.map((title) => (
                    <li key={title}>
                      <button
                        type="button"
                        className="press w-full rounded-sm border border-line px-3 py-2 text-start text-sm"
                        onClick={() => apply(idea.id, { title })}
                      >
                        {title}
                      </button>
                    </li>
                  ))}
                </ul>
                {draft.hook && (
                  <div className="mt-3">
                    <p className="text-sm">{draft.hook}</p>
                    <Button variant="line" className="mt-2" onClick={() => apply(idea.id, { hook: draft.hook ?? "" })}>
                      {c.useHook}
                    </Button>
                  </div>
                )}
              </div>
            )}
          </li>
        ))}
      </ul>
      {!visible.length && <p className="text-sm text-muted">{c.ideasHint}</p>}
    </div>
  );
}
