import { useEffect, useState } from "react";
import { BookOpen, CalendarDays, Film, Lightbulb, TrendingUp } from "lucide-react";
import { copyOf } from "@/lib/studio/copy";
import { useStudio } from "@/lib/studio/store";
import type { NavId } from "@/lib/studio/types";
import { GuideView } from "./guide-view";
import { GrowthView } from "./growth-view";
import { IdeasView } from "./ideas-view";
import { Onboarding } from "./onboarding";
import { ProjectView } from "./project-view";
import { TodayView } from "./today-view";
import { LangSwitch, Mark } from "./ui";
import { cn } from "@/lib/utils";

const ICONS = {
  today: CalendarDays,
  ideas: Lightbulb,
  project: Film,
  growth: TrendingUp,
  guide: BookOpen,
} as const;

export function StudioApp() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    if (useStudio.persist.hasHydrated()) {
      setHydrated(true);
      return;
    }
    return useStudio.persist.onFinishHydration(() => setHydrated(true));
  }, []);
  if (!hydrated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-bg text-fg">
        <div className="flex items-center gap-3 text-xl">
          <Mark className="size-8" />
          لقطة
        </div>
      </div>
    );
  }
  return <StudioReady />;
}

function StudioReady() {
  const profile = useStudio((s) => s.profile);
  const nav = useStudio((s) => s.nav);
  const setNav = useStudio((s) => s.setNav);
  const setLang = useStudio((s) => s.setLang);
  const c = copyOf(profile.lang);

  useEffect(() => {
    document.documentElement.lang = profile.lang;
    document.documentElement.dir = profile.lang === "ar" ? "rtl" : "ltr";
    document.title = profile.lang === "ar" ? "لقطة — استوديو اليوتيوبر المبتدئ" : "Laqta — beginner YouTube studio";
  }, [profile.lang]);

  if (!profile.onboarded) return <Onboarding />;

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="sticky top-0 z-10 flex h-16 items-center justify-between gap-3 border-b border-line bg-bg px-4 md:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <Mark className="size-7 shrink-0" />
          <div className="min-w-0">
            <div className="leading-none">{c.app}</div>
            <div className="mt-1 truncate text-xs text-subtle">{profile.channel}</div>
          </div>
        </div>
        <LangSwitch lang={profile.lang} onChange={setLang} ar={c.langAr} en={c.langEn} />
      </header>
      <div className="mx-auto flex w-full max-w-5xl">
        <aside className="sticky top-16 hidden h-[calc(100vh-4rem)] w-52 shrink-0 border-e border-line p-3 md:block">
          <nav className="flex flex-col gap-1">
            {(Object.keys(ICONS) as NavId[]).map((id) => (
              <NavButton key={id} id={id} current={nav} label={c.nav[id]} onClick={() => setNav(id)} />
            ))}
          </nav>
        </aside>
        <main className="min-w-0 flex-1 px-4 py-6 pb-24 md:px-8 md:pb-10">
          {nav === "today" && <TodayView c={c} />}
          {nav === "ideas" && <IdeasView c={c} />}
          {nav === "project" && <ProjectView c={c} />}
          {nav === "growth" && <GrowthView c={c} />}
          {nav === "guide" && <GuideView c={c} />}
        </main>
      </div>
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-10 border-t border-line bg-bg md:hidden">
        <ul className="grid h-16 grid-cols-5">
          {(Object.keys(ICONS) as NavId[]).map((id) => {
            const Icon = ICONS[id];
            const on = nav === id;
            return (
              <li key={id}>
                <button
                  type="button"
                  onClick={() => setNav(id)}
                  className={cn("flex h-full w-full flex-col items-center justify-center gap-1 text-xs", on ? "text-fg" : "text-subtle")}
                >
                  <Icon className="size-5" strokeWidth={1.75} />
                  {c.nav[id]}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

function NavButton({
  id,
  current,
  label,
  onClick,
}: {
  id: NavId;
  current: NavId;
  label: string;
  onClick: () => void;
}) {
  const Icon = ICONS[id];
  const on = current === id;
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "press flex h-11 items-center gap-3 rounded-sm px-3 text-sm",
        on ? "bg-accent text-accent-fg" : "text-muted",
      )}
    >
      <Icon className="size-4" strokeWidth={1.75} />
      {label}
    </button>
  );
}
