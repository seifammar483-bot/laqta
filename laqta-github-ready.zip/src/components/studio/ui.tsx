import { useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path
        d="M8 13V9h5M24 13V9h-5M8 19v4h5M24 19v4h-5"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="miter"
      />
      <circle cx="16" cy="16" r="2.2" className="fill-signal" />
    </svg>
  );
}

export function Button({
  variant = "primary",
  className,
  children,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "line" | "quiet" }) {
  return (
    <button
      type={type}
      className={cn(
        "press inline-flex h-11 items-center justify-center gap-2 rounded-sm px-4 text-sm font-medium disabled:opacity-40",
        variant === "primary" && "bg-accent text-accent-fg",
        variant === "line" && "border border-line bg-surface text-fg",
        variant === "quiet" && "bg-transparent text-muted",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-muted">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "w-full rounded-sm border border-line bg-bg px-3 text-base text-fg outline-none placeholder:text-subtle";

export function LangSwitch({
  lang,
  onChange,
  ar,
  en,
}: {
  lang: "ar" | "en";
  onChange: (lang: "ar" | "en") => void;
  ar: string;
  en: string;
}) {
  return (
    <div className="flex rounded-lg bg-surface p-1">
      {(
        [
          ["ar", ar],
          ["en", en],
        ] as const
      ).map(([id, label]) => (
        <button
          key={id}
          type="button"
          aria-pressed={lang === id}
          onClick={() => onChange(id)}
          className={cn(
            "press h-9 rounded-sm px-3 text-sm",
            lang === id ? "bg-accent text-accent-fg" : "text-muted",
          )}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

export function useCopyFlash() {
  const [copied, setCopied] = useState<string | null>(null);
  async function copy(key: string, text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied((current) => (current === key ? null : current)), 1400);
    } catch {
      setCopied(null);
    }
  }
  return { copied, copy };
}
