import { useState } from "react";
import { GUIDE, NICHES } from "@/lib/studio/catalog";
import type { Copy } from "@/lib/studio/copy";
import { useStudio } from "@/lib/studio/store";
import type { Cadence, NicheId } from "@/lib/studio/types";
import { fieldClass } from "./ui";
import { cn } from "@/lib/utils";

export function GuideView({ c }: { c: Copy }) {
  const profile = useStudio((s) => s.profile);
  const patch = useStudio((s) => s.patchProfile);
  const lang = profile.lang;
  const [open, setOpen] = useState(GUIDE[0]?.id ?? "month");

  return (
    <div className="rise space-y-6">
      <div>
        <h1 className="text-3xl">{c.guideTitle}</h1>
        <p className="mt-2 text-sm text-muted">{c.guideHint}</p>
      </div>
      <div className="space-y-2">
        {GUIDE.map((section) => {
          const on = open === section.id;
          return (
            <section key={section.id} className="rounded-xl border border-line">
              <button
                type="button"
                aria-expanded={on}
                onClick={() => setOpen(on ? "" : section.id)}
                className="press flex min-h-11 w-full items-center justify-between px-4 py-3 text-start"
              >
                <span className="text-base">{section.title[lang]}</span>
                <span className="text-sm text-subtle">{on ? "–" : "+"}</span>
              </button>
              {on && (
                <div className="space-y-3 border-t border-line px-4 py-4">
                  {section.body[lang].map((paragraph) => (
                    <p key={paragraph} className="text-sm text-muted">
                      {paragraph}
                    </p>
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>
      <section className="border-t border-line pt-5">
        <h2 className="text-lg">{c.settings}</h2>
        <p className="mt-2 text-sm text-muted">{c.settingsHint}</p>
        <label className="mt-4 block text-sm text-muted">
          {c.channel}
          <input
            dir="auto"
            value={profile.channel}
            onChange={(event) => patch({ channel: event.target.value })}
            className={cn(fieldClass, "mt-2 h-11")}
          />
        </label>
        <label className="mt-4 block text-sm text-muted">
          {c.niche}
          <select
            value={profile.niche}
            onChange={(event) => patch({ niche: event.target.value as NicheId })}
            className={cn(fieldClass, "mt-2 h-11")}
          >
            {NICHES.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name[lang]}
              </option>
            ))}
          </select>
        </label>
        <div className="mt-4">
          <div className="text-sm text-muted">{c.cadence}</div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(
              [
                ["short", c.short],
                ["long", c.long],
                ["mix", c.mix],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                aria-pressed={profile.format === id}
                onClick={() => patch({ format: id as Cadence })}
                className={cn(
                  "press h-11 rounded-sm text-sm",
                  profile.format === id ? "bg-accent text-accent-fg" : "border border-line",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-4">
          <div className="text-sm text-muted">{c.perWeek}</div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {([1, 2, 3] as const).map((n) => (
              <button
                key={n}
                type="button"
                aria-pressed={profile.perWeek === n}
                onClick={() => patch({ perWeek: n })}
                className={cn(
                  "press h-11 rounded-sm text-sm",
                  profile.perWeek === n ? "bg-accent text-accent-fg" : "border border-line",
                )}
              >
                {c.times(n)}
              </button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
