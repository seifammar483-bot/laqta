import { DAILY, nicheById } from "@/lib/studio/catalog";
import type { Copy } from "@/lib/studio/copy";
import { WEEKDAYS, dayIndex, nextStepId, planDays } from "@/lib/studio/engine";
import { selectActive, useStudio } from "@/lib/studio/store";
import type { ProjectTab, StepId } from "@/lib/studio/types";
import { Button } from "./ui";
import { cn } from "@/lib/utils";

function tabFor(step: StepId): ProjectTab {
  if (step === "thumb") return "thumb";
  if (step === "pack" || step === "done") return "pack";
  if (step === "title") return "title";
  return "script";
}

export function TodayView({ c }: { c: Copy }) {
  const profile = useStudio((s) => s.profile);
  const ideas = useStudio((s) => s.ideas);
  const projects = useStudio((s) => s.projects);
  const active = useStudio(selectActive);
  const setNav = useStudio((s) => s.setNav);
  const setTab = useStudio((s) => s.setProjectTab);
  const lang = profile.lang;
  const niche = nicheById(profile.niche);
  const saved = ideas.filter((idea) => idea.saved).length;
  const drafts = projects.filter((item) => item.status === "draft").length;
  const published = projects.filter((item) => item.status === "published").length;
  const days = planDays(profile.perWeek);
  const today = new Date().getDay();
  const note = DAILY[lang][dayIndex() % DAILY[lang].length] ?? DAILY[lang][0];
  const subsPct = Math.max(0, Math.min(100, Math.round((profile.subsNow / Math.max(profile.subsGoal, 1)) * 100)));
  const step = active ? nextStepId(active) : null;

  return (
    <div className="rise space-y-6">
      <div>
        <p className="text-sm text-subtle">{c.studio}</p>
        <h1 className="mt-2 text-3xl">{c.hello(profile.channel)}</h1>
      </div>
      {active && step ? (
        <section className="rounded-xl bg-surface p-4">
          <p className="text-xs text-subtle">{c.nextStep}</p>
          <h2 className="mt-2 text-2xl">{c.steps[step].title}</h2>
          <p className="mt-3 text-sm text-muted">{c.steps[step].detail}</p>
          <p className="mt-4 text-base">{active.title}</p>
          <p className="mt-3 text-sm text-muted">
            <span className="text-subtle">{c.hookLabel}. </span>
            {active.hook}
          </p>
          <p className="mt-3 text-sm">{niche.tip[lang]}</p>
          <Button
            className="mt-5"
            onClick={() => {
              setTab(tabFor(step));
              setNav("project");
            }}
          >
            {c.openStep}
          </Button>
        </section>
      ) : (
        <section className="rounded-xl bg-surface p-4">
          <h2 className="text-xl">{c.noProject}</h2>
          <Button className="mt-4" onClick={() => setNav("ideas")}>
            {c.pickIdea}
          </Button>
        </section>
      )}
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        {[
          [c.streak, String(profile.streak)],
          [c.saved, String(saved)],
          [c.drafts, String(drafts)],
          [c.published, String(published)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-xl bg-surface px-4 py-3">
            <div className="text-xs text-muted">{label}</div>
            <div className="mt-1 text-xl tabular-nums">{value}</div>
          </div>
        ))}
      </div>
      <p className="text-xs text-subtle">{c.streakHint}</p>
      <section>
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <h2 className="text-lg">{c.subs}</h2>
          <span className="text-sm tabular-nums text-muted">
            {profile.subsNow} / {profile.subsGoal}
          </span>
        </div>
        <div className="h-1 rounded-full bg-surface-2">
          <div className="h-1 rounded-full bg-fg" style={{ width: `${subsPct}%` }} />
        </div>
      </section>
      <section>
        <h2 className="text-lg">{c.weekPlan}</h2>
        <ul className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {days.map((day) => (
            <li
              key={day}
              className={cn(
                "rounded-lg border border-line px-3 py-3 text-sm",
                day === today && "bg-accent text-accent-fg",
              )}
            >
              <div className="font-medium">{WEEKDAYS[lang][day]}</div>
              <div className={cn("mt-1 text-xs", day === today ? "text-accent-fg/70" : "text-muted")}>
                {c.publishDay}
              </div>
            </li>
          ))}
        </ul>
      </section>
      <section className="border-t border-line pt-4">
        <h2 className="text-sm text-subtle">{c.note}</h2>
        <p className="mt-2 text-base">{note}</p>
      </section>
    </div>
  );
}
