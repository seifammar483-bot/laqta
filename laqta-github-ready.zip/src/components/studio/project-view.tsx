import { useState } from "react";
import { FILM_CHECKS, PUBLISH_CHECKS, nicheById } from "@/lib/studio/catalog";
import type { Copy } from "@/lib/studio/copy";
import { altTitles, buildBeats, buildDescription, checkedCount, scoreTitle, wordCount } from "@/lib/studio/engine";
import { selectActive, useStudio } from "@/lib/studio/store";
import type { Project, ProjectTab } from "@/lib/studio/types";
import { Button, fieldClass, useCopyFlash } from "./ui";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

export function ProjectView({ c }: { c: Copy }) {
  const projects = useStudio((s) => s.projects);
  const active = useStudio(selectActive);
  const tab = useStudio((s) => s.projectTab);
  const setTab = useStudio((s) => s.setProjectTab);
  const update = useStudio((s) => s.updateProject);
  const toggle = useStudio((s) => s.toggleCheck);
  const setBeat = useStudio((s) => s.setBeat);
  const mark = useStudio((s) => s.markPublished);
  const setNav = useStudio((s) => s.setNav);
  const uiLang = useStudio((s) => s.profile.lang);
  const { copied, copy } = useCopyFlash();
  const [publishing, setPublishing] = useState(false);
  const [views, setViews] = useState("0");
  const [note, setNote] = useState("");

  if (!active) {
    return (
      <div className="rise">
        <h1 className="text-3xl">{c.projectTitle}</h1>
        <p className="mt-3 text-muted">{c.emptyProject}</p>
        <Button className="mt-5" onClick={() => setNav("ideas")}>
          {c.goIdeas}
        </Button>
      </div>
    );
  }

  const score = scoreTitle(active.title, uiLang);
  const words = wordCount(active.thumbText);
  const alternatives = altTitles(active);
  const niche = nicheById(active.niche);

  return (
    <div className="rise space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs text-subtle">
            {niche.name[active.lang]} · {active.format === "short" ? c.short : c.long}
          </p>
          <h1 className="mt-2 text-2xl">{c.projectTitle}</h1>
        </div>
        <span className="rounded-full border border-line px-3 py-1 text-xs">
          {active.status === "published" ? c.statusLive : c.statusDraft}
        </span>
      </div>
      {projects.length > 1 && (
        <label className="block text-sm text-muted">
          {c.switchProject}
          <select
            value={active.id}
            onChange={(event) => useStudio.setState({ activeProjectId: event.target.value })}
            className="mt-2 h-11 w-full rounded-sm border border-line bg-surface px-3 text-sm text-fg"
          >
            {projects.map((project, index) => (
              <option key={project.id} value={project.id}>
                {index + 1}. {project.title}
              </option>
            ))}
          </select>
        </label>
      )}
      <div className="grid grid-cols-4 gap-1 rounded-lg bg-surface p-1" role="tablist">
        {(Object.keys(c.tabs) as ProjectTab[]).map((id) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className={cn("press h-10 rounded-sm text-sm", tab === id ? "bg-accent text-accent-fg" : "text-muted")}
          >
            {c.tabs[id]}
          </button>
        ))}
      </div>
      {tab === "title" && (
        <TitlePane
          c={c}
          project={active}
          score={score.score}
          notes={score.notes}
          alternatives={alternatives}
          onTitle={(title) => update(active.id, { title })}
        />
      )}
      {tab === "script" && (
        <section className="space-y-4">
          <p className="text-sm text-muted">{c.scriptHint}</p>
          <CheckList
            items={FILM_CHECKS}
            lang={uiLang}
            values={active.film}
            onToggle={(key) => toggle(active.id, key, "film")}
            done={checkedCount(active.film)}
            total={FILM_CHECKS.length}
          />
          {active.beats.map((beat, index) => (
            <label key={beat.id} className="block">
              <span className="flex items-baseline justify-between gap-3 text-sm">
                <span>
                  {c.beatHint} {index + 1} — {beat.label}
                </span>
                <span className="tabular-nums text-subtle">{beat.seconds}</span>
              </span>
              <textarea
                dir="auto"
                value={beat.body}
                onChange={(event) => setBeat(active.id, beat.id, event.target.value)}
                className={cn(fieldClass, "mt-2 min-h-24 py-3")}
              />
            </label>
          ))}
        </section>
      )}
      {tab === "thumb" && (
        <section className="space-y-4">
          <p className="text-sm text-muted">{c.thumbHint}</p>
          <input
            dir="auto"
            value={active.thumbText}
            onChange={(event) => update(active.id, { thumbText: event.target.value })}
            className={cn(fieldClass, "h-12 text-lg")}
          />
          <p className={cn("text-sm tabular-nums", words > 4 || words === 0 ? "text-signal" : "text-muted")}>
            {c.thumbCount(words)} — {words > 4 || words === 0 ? c.thumbBad : c.thumbGood}
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-surface p-4">
              <h2 className="text-sm text-subtle">{c.doList}</h2>
              <ul className="mt-2 space-y-2 text-sm">
                {c.dos.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl bg-surface p-4">
              <h2 className="text-sm text-subtle">{c.dontList}</h2>
              <ul className="mt-2 space-y-2 text-sm">
                {c.donts.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      )}
      {tab === "pack" && (
        <section className="space-y-4">
          {nextReady(active) && <p className="text-sm">{c.filmReady}</p>}
          <div className="flex flex-wrap gap-2">
            <Button
              variant="line"
              onClick={() =>
                copy(
                  "pack",
                  `${active.title}\n\n${active.thumbText}\n\n${active.description}\n\n${active.tags.join(", ")}`,
                )
              }
            >
              {copied === "pack" ? c.copied : c.copyPack}
            </Button>
            <Button
              variant="quiet"
              onClick={() => {
                const beats = buildBeats(active, niche);
                update(active.id, { description: buildDescription(active, niche, beats) });
              }}
            >
              {c.refreshDesc}
            </Button>
          </div>
          <label className="block">
            <span className="mb-2 flex items-center justify-between text-sm text-muted">
              {c.description}
              <button type="button" className="text-fg" onClick={() => copy("desc", active.description)}>
                {copied === "desc" ? c.copied : c.copy}
              </button>
            </span>
            <textarea
              dir="auto"
              value={active.description}
              onChange={(event) => update(active.id, { description: event.target.value })}
              className={cn(fieldClass, "min-h-40 py-3")}
            />
          </label>
          <div>
            <div className="mb-2 text-sm text-muted">{c.tags}</div>
            <ul className="flex flex-wrap gap-2">
              {active.tags.map((tag) => (
                <li key={tag}>
                  <button
                    type="button"
                    onClick={() => copy(tag, tag)}
                    className="press h-8 rounded-full border border-line px-3 text-xs"
                  >
                    {copied === tag ? c.copied : tag}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <CheckList
            items={PUBLISH_CHECKS}
            lang={uiLang}
            values={active.checklist}
            onToggle={(key) => toggle(active.id, key, "checklist")}
            done={checkedCount(active.checklist)}
            total={PUBLISH_CHECKS.length}
          />
          {active.status === "draft" && !publishing && (
            <Button
              onClick={() => {
                setPublishing(true);
                setViews("0");
                setNote("");
              }}
            >
              {c.publishCta}
            </Button>
          )}
          {publishing && active.status === "draft" && (
            <div className="rounded-xl bg-surface p-4">
              <label className="block text-sm text-muted">
                {c.views}
                <input
                  inputMode="numeric"
                  value={views}
                  onChange={(event) => setViews(event.target.value.replace(/[^\d]/g, ""))}
                  placeholder={c.viewsPh}
                  className={cn(fieldClass, "mt-2 h-11 tabular-nums")}
                />
              </label>
              <label className="mt-3 block text-sm text-muted">
                {c.lesson}
                <input
                  dir="auto"
                  value={note}
                  onChange={(event) => setNote(event.target.value)}
                  placeholder={c.notePh}
                  className={cn(fieldClass, "mt-2 h-11")}
                />
              </label>
              <div className="mt-4 flex gap-2">
                <Button
                  onClick={() => mark(active.id, Number(views || 0), note)}
                >
                  {c.confirmPublish}
                </Button>
                <Button variant="line" onClick={() => setPublishing(false)}>
                  {c.cancel}
                </Button>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

function nextReady(project: Project) {
  return scoreTitle(project.title, project.lang).score >= 65 && wordCount(project.thumbText) > 0 && wordCount(project.thumbText) <= 4;
}

function TitlePane({
  c,
  project,
  score,
  notes,
  alternatives,
  onTitle,
}: {
  c: Copy;
  project: Project;
  score: number;
  notes: { tone: "good" | "bad" | "warn"; text: string }[];
  alternatives: string[];
  onTitle: (title: string) => void;
}) {
  return (
    <section className="space-y-4">
      <textarea
        dir="auto"
        value={project.title}
        onChange={(event) => onTitle(event.target.value)}
        placeholder={c.titlePh}
        className={cn(fieldClass, "min-h-24 py-3 text-lg")}
      />
      <div>
        <div className="flex items-baseline justify-between text-sm">
          <span className="text-muted">{c.score}</span>
          <span className="tabular-nums">
            {score}
            <span className="text-subtle"> / 100</span>
            <span className="ms-3 text-subtle">
              {project.title.trim().length} {c.chars}
            </span>
          </span>
        </div>
        <div className="mt-2 h-1 rounded-full bg-surface-2">
          <div
            className={cn("h-1 rounded-full", score < 50 ? "bg-signal" : "bg-fg")}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
      <ul className="space-y-2">
        {notes.slice(0, 4).map((note) => (
          <li key={note.text} className={cn("text-sm", note.tone === "bad" ? "text-signal" : "text-muted")}>
            {note.text}
          </li>
        ))}
      </ul>
      <ul className="space-y-2">
        {alternatives.map((title) => (
          <li key={title}>
            <button
              type="button"
              onClick={() => onTitle(title)}
              className="press w-full rounded-sm border border-line px-3 py-3 text-start text-sm"
            >
              {title}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

function CheckList({
  items,
  lang,
  values,
  onToggle,
  done,
  total,
}: {
  items: { id: string; text: { ar: string; en: string } }[];
  lang: "ar" | "en";
  values: Record<string, boolean>;
  onToggle: (id: string) => void;
  done: number;
  total: number;
}) {
  return (
    <div>
      <p className="mb-2 text-sm tabular-nums text-subtle">
        {done} / {total}
      </p>
      <ul className="space-y-2">
        {items.map((item) => {
          const on = Boolean(values[item.id]);
          return (
            <li key={item.id}>
              <button
                type="button"
                role="checkbox"
                aria-checked={on}
                onClick={() => onToggle(item.id)}
                className="press flex min-h-11 w-full items-start gap-3 rounded-lg border border-line px-3 py-3 text-start"
              >
                <span
                  className={cn(
                    "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-xs border border-line",
                    on && "border-accent bg-accent text-accent-fg",
                  )}
                >
                  {on && <Check className="size-3.5" strokeWidth={2.5} />}
                </span>
                <span className="text-sm">{item.text[lang]}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
