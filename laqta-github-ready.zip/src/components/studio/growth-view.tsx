import { useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { MILESTONES } from "@/lib/studio/catalog";
import type { Copy } from "@/lib/studio/copy";
import { growthInsight } from "@/lib/studio/engine";
import { useStudio } from "@/lib/studio/store";
import { Button, fieldClass } from "./ui";
import { cn } from "@/lib/utils";

export function GrowthView({ c }: { c: Copy }) {
  const profile = useStudio((s) => s.profile);
  const projects = useStudio((s) => s.projects);
  const patch = useStudio((s) => s.patchProfile);
  const setViews = useStudio((s) => s.setViews);
  const lang = profile.lang;
  const published = projects.filter((item) => item.status === "published");
  const videoCount = published.length;
  const next = MILESTONES.find((item) => (item.metric === "videos" ? videoCount < item.n : profile.subsNow < item.n));
  const currentValue = next ? (next.metric === "videos" ? videoCount : profile.subsNow) : 0;
  const pct = next ? Math.max(0, Math.min(100, Math.round((currentValue / next.n) * 100))) : 100;
  const data = [...published]
    .sort((a, b) => (a.publishedAt ?? "").localeCompare(b.publishedAt ?? ""))
    .map((item, index) => ({ name: String(index + 1), views: item.views ?? 0, title: item.title }));

  return (
    <div className="rise space-y-6">
      <div>
        <h1 className="text-3xl">{c.growthTitle}</h1>
        <p className="mt-2 text-sm text-muted">{c.growthHint}</p>
      </div>
      <section className="rounded-xl bg-surface p-4">
        <p className="text-xs text-subtle">{c.insight}</p>
        <p className="mt-2 text-base">{growthInsight(projects, lang)}</p>
      </section>
      <section>
        <h2 className="text-lg">{next ? c.milestone : c.reached}</h2>
        {next ? (
          <>
            <p className="mt-2 text-xl">{next.title[lang]}</p>
            <p className="mt-2 text-sm text-muted">{next.body[lang]}</p>
            <div className="mt-3 flex items-baseline justify-between text-sm tabular-nums text-muted">
              <span>{c.now}</span>
              <span>
                {currentValue} / {next.n}
              </span>
            </div>
            <div className="mt-2 h-1 rounded-full bg-surface-2">
              <div className="h-1 rounded-full bg-fg" style={{ width: `${pct}%` }} />
            </div>
          </>
        ) : (
          <p className="mt-2 text-sm text-muted">{MILESTONES[MILESTONES.length - 1]?.body[lang]}</p>
        )}
      </section>
      <label className="block text-sm text-muted">
        {c.subsNow}
        <input
          inputMode="numeric"
          value={String(profile.subsNow)}
          onChange={(event) => {
            const raw = event.target.value.replace(/[^\d]/g, "");
            patch({ subsNow: raw ? Number(raw) : 0 });
          }}
          className={cn(fieldClass, "mt-2 h-11 max-w-xs tabular-nums")}
        />
      </label>
      <section>
        <h2 className="text-lg">{c.views}</h2>
        {data.length ? (
          <div className="mt-3 h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  cursor={{ fill: "var(--color-surface-2)" }}
                  content={({ active, payload }) => {
                    if (!active || !payload?.length) return null;
                    const row = payload[0]?.payload as { title?: string; views?: number } | undefined;
                    return (
                      <div className="max-w-xs rounded-sm border border-line bg-surface px-3 py-2 text-sm">
                        <div>{row?.title}</div>
                        <div className="mt-1 tabular-nums text-muted">{row?.views ?? 0}</div>
                      </div>
                    );
                  }}
                />
                <Bar dataKey="views" fill="var(--color-fg)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="mt-2 text-sm text-muted">{c.noChart}</p>
        )}
        <ul className="mt-4 space-y-3">
          {published.map((project) => (
            <PublishedRow key={project.id} id={project.id} title={project.title} views={project.views ?? 0} note={project.note ?? ""} c={c} onSave={setViews} />
          ))}
        </ul>
      </section>
    </div>
  );
}

function PublishedRow({
  id,
  title,
  views,
  note,
  c,
  onSave,
}: {
  id: string;
  title: string;
  views: number;
  note: string;
  c: Copy;
  onSave: (id: string, views: number, note: string) => void;
}) {
  const [count, setCount] = useState(String(views));
  const [lesson, setLesson] = useState(note);
  return (
    <li className="rounded-xl border border-line p-4">
      <h3 className="text-base">{title}</h3>
      <div className="mt-3 grid gap-2 sm:grid-cols-[8rem_1fr_auto]">
        <input
          inputMode="numeric"
          aria-label={c.views}
          value={count}
          onChange={(event) => setCount(event.target.value.replace(/[^\d]/g, ""))}
          className={cn(fieldClass, "h-11 tabular-nums")}
        />
        <input
          dir="auto"
          aria-label={c.lesson}
          value={lesson}
          onChange={(event) => setLesson(event.target.value)}
          placeholder={c.notePh}
          className={cn(fieldClass, "h-11")}
        />
        <Button variant="line" onClick={() => onSave(id, Number(count || 0), lesson)}>
          {c.saveNumbers}
        </Button>
      </div>
    </li>
  );
}
