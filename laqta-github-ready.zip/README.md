# Laqta

Laqta is a React + TypeScript web application built with TanStack Start, Vite, and Tailwind CSS.

## Requirements

- Node.js 22 or newer
- npm

## Getting started

```bash
git clone <YOUR_REPOSITORY_URL>
cd laqta
npm ci
```

Create the local app environment file:

```bash
mkdir -p .grok
cp .grok/app-env.example.json .grok/app-env.json
```

Start the development server:

```bash
npm run dev
```

The app is configured to be served on port `8080`.

## Available scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server |
| `npm run build` | Build the production app and run database migrations |
| `npm run preview` | Preview the production build |
| `npm run typecheck` | Run TypeScript checks |
| `npm run lint` | Run ESLint |
| `npm test` | Run the test suite |
| `npm run db:migrate` | Apply database migrations |

## Environment configuration

The repository intentionally does not include credentials or private environment files.

- `.grok/app-env.json` is a local build-flag file. Start from `.grok/app-env.example.json`.
- For deployments that use authentication or a hosted database, configure the required environment variables in your hosting provider's project settings. Never commit API keys, database URLs, OAuth secrets, or `.env` files.
- `VITE_` variables are exposed to the browser. Do not put secrets in variables with this prefix.

## Deployment

The project includes a `vercel.json` configuration. Import the repository into Vercel, configure the environment variables required by the enabled application features, and deploy.

## Before publishing

1. Review the source and remove any credentials or private data you may add later.
2. Update the repository URL and project description.
3. Choose and add a license if you own the rights to distribute this project.
4. Configure environment variables in GitHub/Vercel Secrets rather than committing them.
